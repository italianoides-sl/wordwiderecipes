/* worldwiderecipes.app — Browse page React */

const { useState, useEffect, useMemo, useRef, useCallback } = React;

/* ================================================
   Filter bar (sticky, scrollable on mobile)
   ================================================ */
function FilterBar({ groups, active, setActive, resultCount, sortBy, setSortBy }) {
  const isActive = (gid, oid) => active[gid] && active[gid].includes(oid);

  function toggle(gid, oid) {
    setActive((prev) => {
      const set = new Set(prev[gid] || []);
      if (set.has(oid)) set.delete(oid); else set.add(oid);
      return { ...prev, [gid]: [...set] };
    });
  }
  function clearOne(gid, oid) {
    setActive((prev) => {
      const set = new Set(prev[gid] || []);
      set.delete(oid);
      return { ...prev, [gid]: [...set] };
    });
  }
  function clearAll() {
    setActive({});
  }

  const totalActive = Object.values(active).reduce((n, arr) => n + arr.length, 0);

  return (
    <div className="bp-filterbar">
      <div className="bp-filterbar-inner">
        <div className="bp-filter-groups" role="toolbar" aria-label="Filtros">
          {groups.map((g) => (
            <div className="bp-filter-group" key={g.id}>
              <span className="bp-filter-label">
                <span className="bp-filter-icon" aria-hidden="true">{g.icon}</span>
                {g.label}
              </span>
              <div className="bp-pill-row">
                {g.options.map((o) => {
                  const on = isActive(g.id, o.id);
                  return (
                    <button
                      key={o.id}
                      type="button"
                      className={`bp-pill ${on ? "is-active" : ""} ${o.isMore ? "is-more" : ""}`}
                      onClick={() => !o.isMore && toggle(g.id, o.id)}
                      aria-pressed={on}
                    >
                      {o.flag && <span className="bp-pill-flag" aria-hidden="true">{o.flag}</span>}
                      <span className="bp-pill-label">{o.label}</span>
                      {on && (
                        <span
                          className="bp-pill-x"
                          role="button"
                          aria-label={`Quitar ${o.label}`}
                          onClick={(e) => { e.stopPropagation(); clearOne(g.id, o.id); }}
                        >
                          ×
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <div className="bp-filterbar-footer">
          <div className="bp-result-count">
            <span className="bp-rc-number">{resultCount.toLocaleString("es-ES")}</span>
            <span className="bp-rc-label">{resultCount === 1 ? "resultado" : "resultados"}</span>
            {totalActive > 0 && (
              <button className="bp-clear" onClick={clearAll}>Limpiar filtros</button>
            )}
          </div>
          <div className="bp-sort">
            <span className="bp-sort-label">Ordenar por</span>
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
              <option value="trending">Tendencia</option>
              <option value="recent">Más recientes</option>
              <option value="popular">Más populares</option>
              <option value="quick">Más rápidas</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================================================
   Card image (decorative gradient with food-themed pattern)
   ================================================ */
function CardImage({ from, to, tone, type, locale }) {
  const typeMeta = window.BROWSE.typeMeta[type] || {};
  return (
    <div className="bp-card-img" style={{ background: `linear-gradient(135deg, ${from} 0%, ${to} 100%)` }}>
      <div className="bp-card-img-grain" aria-hidden="true"></div>
      <span className="bp-card-type" style={{ background: typeMeta.color }}>
        {typeMeta.label}
      </span>
      {locale && (
        <span className="bp-card-locale" title={`Versión ${locale.toUpperCase()}`}>
          <span aria-hidden="true">{locale === "mx" ? "🇲🇽" : locale === "es" ? "🇪🇸" : "🌍"}</span>
          {locale.toUpperCase()}
        </span>
      )}
    </div>
  );
}

/* ================================================
   Recipe / content card
   ================================================ */
function ContentCard({ card }) {
  return (
    <a className="bp-card" href={`#/recipe/${card.id}`} style={{ "--img-aspect": card.tall }}>
      <CardImage
        from={card.img.from}
        to={card.img.to}
        tone={card.img.tone}
        type={card.type}
        locale={card.locale}
      />
      <div className="bp-card-body">
        <h3 className="bp-card-title">{card.title}</h3>
        <div className="bp-card-meta">
          <span className="bp-card-flag" aria-hidden="true">{card.country.flag}</span>
          <span className="bp-card-country">{card.country.name}</span>
          <span aria-hidden="true" className="bp-card-dot">·</span>
          <span className="bp-card-time">{card.time}</span>
          {card.difficulty && (
            <>
              <span aria-hidden="true" className="bp-card-dot">·</span>
              <span className="bp-card-diff">{card.difficulty}</span>
            </>
          )}
          {card.affiliate && (
            <span className="bp-card-affiliate" title="Esta página contiene enlaces de afiliado" aria-label="Contiene enlaces de afiliado">
              <span className="bp-aff-dot" aria-hidden="true"></span>
            </span>
          )}
        </div>
      </div>
    </a>
  );
}

/* ================================================
   Skeleton card
   ================================================ */
function SkeletonCard({ aspect = 1 }) {
  return (
    <div className="bp-card bp-skeleton" aria-hidden="true" style={{ "--img-aspect": aspect }}>
      <div className="bp-card-img bp-sk-img">
        <span className="bp-sk-type"></span>
      </div>
      <div className="bp-card-body">
        <div className="bp-sk-title-1"></div>
        <div className="bp-sk-title-2"></div>
        <div className="bp-sk-meta"></div>
      </div>
    </div>
  );
}

/* ================================================
   Page header
   ================================================ */
function BrowseHeader() {
  return (
    <header className="bp-header">
      <div className="bp-bc">
        <a href="#/">Inicio</a>
        <span aria-hidden="true">›</span>
        <span aria-current="page">Recetas</span>
      </div>
      <h1 className="bp-h1">
        El <em>recetario</em> del mundo.
      </h1>
      <p className="bp-lede">
        2.148 recetas, técnicas e ingredientes de cocinas que cruzan océanos. Filtra por país, tiempo o dieta — o déjate guiar por las tendencias del día.
      </p>
    </header>
  );
}

/* ================================================
   Browse Page
   ================================================ */
function BrowsePage() {
  const data = window.BROWSE;
  const [active, setActive] = useState({});
  const [sortBy, setSortBy] = useState("trending");
  const [pageNum, setPageNum] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const sentinelRef = useRef(null);

  /* ---- Filter the cards ---- */
  const filtered = useMemo(() => {
    return data.cards.filter((c) => {
      // tipo
      if (active.tipo?.length && !active.tipo.includes(c.type)) return false;
      // pais
      if (active.pais?.length && !active.pais.filter((p) => p !== "more").includes(c.country.code)) {
        // if there are non-"more" entries selected, must match
        const real = active.pais.filter((p) => p !== "more");
        if (real.length && !real.includes(c.country.code)) return false;
      }
      // dieta
      if (active.dieta?.length && !active.dieta.some((d) => c.diet?.includes(d))) return false;
      // tiempo (rough parse of c.time when it's a cook time, not "X min de lectura")
      if (active.tiempo?.length) {
        const t = c.time.toLowerCase();
        const isLectura = t.includes("lectura");
        const mins = (() => {
          const hMatch = t.match(/(\d+)\s*h(?:\s*(\d+))?/);
          if (hMatch) return parseInt(hMatch[1]) * 60 + (parseInt(hMatch[2]) || 0);
          const mMatch = t.match(/(\d+)\s*min/);
          if (mMatch) return parseInt(mMatch[1]);
          return null;
        })();
        if (isLectura || mins == null) return false;
        const bucket = mins < 30 ? "lt30" : mins <= 60 ? "30-60" : "gt60";
        if (!active.tiempo.includes(bucket)) return false;
      }
      return true;
    });
  }, [active, data.cards]);

  /* The infinite-scroll "feed" = repeat the filtered set pageNum times, with new IDs */
  const visibleCards = useMemo(() => {
    const out = [];
    for (let p = 0; p < pageNum; p++) {
      filtered.forEach((c, i) => {
        out.push({ ...c, id: `${c.id}-${p}-${i}` });
      });
    }
    return out;
  }, [filtered, pageNum]);

  /* Live total count — a believable number that responds to filters */
  const resultCount = useMemo(() => {
    if (Object.values(active).flat().length === 0) return 2148;
    const ratio = filtered.length / data.cards.length;
    return Math.max(filtered.length, Math.round(2148 * ratio));
  }, [filtered, active, data.cards.length]);

  /* Reset paging when filters change */
  useEffect(() => {
    setPageNum(1);
  }, [active, sortBy]);

  /* Infinite scroll observer */
  useEffect(() => {
    if (!sentinelRef.current) return;
    const io = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !isLoading && pageNum < 4) {
        setIsLoading(true);
        setTimeout(() => {
          setPageNum((n) => n + 1);
          setIsLoading(false);
        }, 900);
      }
    }, { rootMargin: "300px" });
    io.observe(sentinelRef.current);
    return () => io.disconnect();
  }, [isLoading, pageNum]);

  const skeletonAspects = [1.05, 0.85, 1.0, 1.1, 0.95, 1.05];

  return (
    <div className="bp-page">
      <header className="bp-topbar">
        <div className="bp-tb-left">domingo, 17 de mayo de 2026 · Edición España &amp; LATAM</div>
        <a href="#/" className="bp-logo">worldwiderecipes<span>.app</span></a>
        <nav className="bp-nav">
          <a href="#/explorar" className="is-current">Explorar</a>
          <a href="#/colecciones">Colecciones</a>
          <a href="#/tiktok">TikTok</a>
          <a href="#/entrar">Entrar</a>
        </nav>
      </header>

      <BrowseHeader />

      <FilterBar
        groups={data.filterGroups}
        active={active}
        setActive={setActive}
        resultCount={resultCount}
        sortBy={sortBy}
        setSortBy={setSortBy}
      />

      <main className="bp-main">
        {filtered.length === 0 ? (
          <div className="bp-empty">
            <span className="bp-empty-eyebrow">Sin resultados</span>
            <h2>Nada coincide con esos filtros.</h2>
            <p>Prueba a quitar uno o explora <a href="#" onClick={(e) => { e.preventDefault(); setActive({}); }}>todas las recetas</a>.</p>
          </div>
        ) : (
          <div className="bp-grid">
            {visibleCards.map((c) => (
              <ContentCard card={c} key={c.id} />
            ))}
            {isLoading && skeletonAspects.map((a, i) => (
              <SkeletonCard key={`sk-${i}`} aspect={a} />
            ))}
          </div>
        )}

        <div ref={sentinelRef} className="bp-sentinel" aria-hidden="true">
          {pageNum >= 4 && !isLoading && filtered.length > 0 && (
            <div className="bp-end">
              <span>—</span> Has llegado al final por ahora <span>—</span>
            </div>
          )}
        </div>
      </main>

      <footer className="bp-footer">
        <span>© 2026 worldwiderecipes.app · Cocinamos desde Madrid y Ciudad de México</span>
        <span><a href="#/about">Quiénes somos</a> · <a href="#/contacto">Contacto</a> · <a href="#/privacidad">Privacidad</a></span>
      </footer>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<BrowsePage />);

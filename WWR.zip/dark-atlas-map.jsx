/* worldwiderecipes.app — Dark Atlas · Explorar (interactive D3 map)
   Loads D3 + TopoJSON dynamically, renders a Natural Earth projection
   with hover tooltip, animated markers, region filter, and side panel. */

const { useState: useStateM, useEffect: useEffectM, useRef: useRefM, useMemo: useMemoM } = React;

/* ============================================================
   Script loader — D3 + TopoJSON
   ============================================================ */
function loadScript(src) {
  return new Promise((resolve, reject) => {
    const existing = document.querySelector(`script[data-da-src="${src}"]`);
    if (existing && existing.dataset.daLoaded === "true") return resolve();
    if (existing) {
      existing.addEventListener("load", resolve);
      existing.addEventListener("error", reject);
      return;
    }
    const s = document.createElement("script");
    s.src = src;
    s.async = false;
    s.dataset.daSrc = src;
    s.addEventListener("load", () => { s.dataset.daLoaded = "true"; resolve(); });
    s.addEventListener("error", reject);
    document.head.appendChild(s);
  });
}

/* ============================================================
   ENGLISH NAME FALLBACK — for matching feature.properties.name
   (the world-atlas TopoJSON may use string IDs or names depending on version)
   ============================================================ */
const NAME_FALLBACK = {
  "484": ["Mexico"],
  "724": ["Spain"],
  "392": ["Japan"],
  "356": ["India"],
  "156": ["China"],
  "380": ["Italy"],
  "250": ["France"],
  "604": ["Peru"],
  "764": ["Thailand"],
  "076": ["Brazil"],
  "504": ["Morocco"],
  "032": ["Argentina"],
  "410": ["South Korea", "Korea, Republic of", "Korea"],
  "300": ["Greece"],
  "792": ["Turkey", "Türkiye"],
  "704": ["Vietnam", "Viet Nam"],
  "170": ["Colombia"],
  "276": ["Germany"],
  "231": ["Ethiopia"],
};

/* ============================================================
   COUNTRY PANEL (slides in from right)
   ============================================================ */
function CountryPanel({ country, onClose }) {
  // ESC closes
  useEffectM(() => {
    if (!country) return;
    const h = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [country, onClose]);

  const articles = useMemoM(() => {
    if (!country) return [];
    const explicit = ARTICLES_BY_COUNTRY[country.id];
    return explicit || placeholderArticlesFor(country);
  }, [country]);

  const breakdown = useMemoM(() => country ? typeBreakdown(country.count) : [], [country]);

  return (
    <>
      <div
        className={`da-panel-overlay ${country ? "is-open" : ""}`}
        onClick={onClose}
        aria-hidden="true"
      />
      <aside
        className={`da-panel ${country ? "is-open" : ""}`}
        aria-hidden={!country}
        aria-label={country ? `Contenido de ${country.name}` : ""}
      >
        {country && (
          <>
            <div className="da-panel-accent" style={{ background: country.color }} />
            <button className="da-panel-close" onClick={onClose} aria-label="Cerrar">
              <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
                <path d="M3 3l10 10M13 3L3 13"/>
              </svg>
            </button>

            <header className="da-panel-head">
              <div className="da-panel-flag">{country.flag}</div>
              <h3 className="da-panel-name">{country.name}</h3>
              <div className="da-panel-meta">
                <span>{country.capital}</span>
                <span className="dot">·</span>
                <span style={{ color: country.color }}>{country.count} artículos</span>
              </div>
            </header>

            <div className="da-panel-section">
              <div className="da-panel-eyebrow">Reparto por tipo</div>
              <div className="da-panel-badges">
                {breakdown.map((b) => {
                  const meta = TYPE_META[b.key];
                  return (
                    <span key={b.key} className="da-panel-badge" style={{ borderColor: meta.color, color: meta.color }}>
                      <span className="badge-icon" aria-hidden="true">{meta.icon}</span>
                      {b.count} {meta.label.toLowerCase()}{b.count !== 1 ? "s" : ""}
                    </span>
                  );
                })}
              </div>
            </div>

            <div className="da-panel-section da-panel-articles">
              <div className="da-panel-eyebrow">Artículos destacados</div>
              <ul className="da-article-list">
                {articles.map((a, i) => {
                  const meta = TYPE_META[a.k];
                  return (
                    <li key={i} className="da-article">
                      <span className="da-article-icon" style={{ background: `${meta.color}22`, color: meta.color }}>
                        {meta.icon}
                      </span>
                      <div className="da-article-body">
                        <div className="da-article-title">{a.t}</div>
                        <div className="da-article-meta">
                          <span className="da-article-type" style={{ color: meta.color }}>{meta.label}</span>
                          <span className="da-article-time">{a.time}</span>
                        </div>
                      </div>
                      <span className="da-article-arrow" aria-hidden="true">→</span>
                    </li>
                  );
                })}
              </ul>
            </div>

            <footer className="da-panel-foot">
              <a className="da-btn da-btn--primary da-btn--full" href="#" onClick={(e) => e.preventDefault()}>
                Ver todos los artículos de {country.name}
                <svg className="da-btn-arrow" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 10h12M11 5l5 5-5 5"/>
                </svg>
              </a>
            </footer>
          </>
        )}
      </aside>
    </>
  );
}

/* ============================================================
   ExplorePage
   ============================================================ */
function ExplorePage({ onBack }) {
  const [ready, setReady] = useStateM(false);
  const [error, setError] = useStateM(null);
  const [selected, setSelected] = useStateM(null);
  const [region, setRegion] = useStateM("all");
  const [tooltip, setTooltip] = useStateM(null);
  const svgRef = useRefM(null);
  const wrapRef = useRefM(null);
  const zoomRef = useRefM(null);
  const gRef = useRefM(null);

  /* Build a name → country lookup */
  const nameMap = useMemoM(() => {
    const m = new Map();
    COUNTRIES.forEach((c) => {
      (NAME_FALLBACK[c.id] || []).forEach((n) => m.set(n.toLowerCase(), c));
      m.set(c.name.toLowerCase(), c);
    });
    return m;
  }, []);

  /* Build id → country lookup (numeric-normalized) */
  const idMap = useMemoM(() => {
    const m = new Map();
    COUNTRIES.forEach((c) => m.set(String(parseInt(c.id, 10)), c));
    return m;
  }, []);

  /* Load D3 + TopoJSON */
  useEffectM(() => {
    let cancelled = false;
    Promise.all([
      loadScript("https://cdnjs.cloudflare.com/ajax/libs/d3/7.8.5/d3.min.js"),
      loadScript("https://cdnjs.cloudflare.com/ajax/libs/topojson/3.0.2/topojson.min.js"),
    ])
      .then(() => { if (!cancelled) setReady(true); })
      .catch((e) => { if (!cancelled) setError(String(e)); });
    return () => { cancelled = true; };
  }, []);

  /* Initialize the map once ready */
  useEffectM(() => {
    if (!ready || !svgRef.current || !wrapRef.current) return;
    const d3 = window.d3;
    const topojson = window.topojson;

    let cancelled = false;
    d3.json("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json")
      .then((world) => {
        if (cancelled || !svgRef.current) return;
        const rect = wrapRef.current.getBoundingClientRect();
        const width = rect.width;
        const height = rect.height;

        const land = topojson.feature(world, world.objects.countries);
        const projection = d3.geoNaturalEarth1().fitSize([width * 0.96, height * 0.95], land);
        projection.translate([
          width / 2,
          height / 2 - (height * 0.02),
        ]);
        const pathGen = d3.geoPath(projection);

        const svg = d3.select(svgRef.current);
        svg.attr("viewBox", `0 0 ${width} ${height}`);
        svg.selectAll("*").remove();

        // Defs (gradient + glow)
        const defs = svg.append("defs");
        const oceanGrad = defs.append("radialGradient")
          .attr("id", "da-ocean").attr("cx", "50%").attr("cy", "55%").attr("r", "75%");
        oceanGrad.append("stop").attr("offset", "0%").attr("stop-color", "#0A1424");
        oceanGrad.append("stop").attr("offset", "100%").attr("stop-color", "#060A14");

        // Filter — soft glow for markers
        const glow = defs.append("filter").attr("id", "da-glow").attr("x", "-100%").attr("y", "-100%")
          .attr("width", "300%").attr("height", "300%");
        glow.append("feGaussianBlur").attr("stdDeviation", "3").attr("result", "blur");
        const merge = glow.append("feMerge");
        merge.append("feMergeNode").attr("in", "blur");
        merge.append("feMergeNode").attr("in", "SourceGraphic");

        // Background ocean rect
        svg.append("rect")
          .attr("width", width).attr("height", height)
          .attr("fill", "url(#da-ocean)");

        // Graticule (subtle)
        const graticule = d3.geoGraticule().step([20, 20]);
        svg.append("path")
          .datum(graticule)
          .attr("d", pathGen)
          .attr("fill", "none")
          .attr("stroke", "rgba(168, 152, 128, 0.05)")
          .attr("stroke-width", 0.4);

        // Zoom group
        const g = svg.append("g").attr("class", "da-map-g");
        gRef.current = g;

        // Helper to find COUNTRY for a feature
        const lookup = (feature) => {
          const idKey = String(parseInt(feature.id, 10));
          if (idMap.has(idKey)) return idMap.get(idKey);
          const name = (feature.properties && feature.properties.name) || "";
          return nameMap.get(name.toLowerCase()) || null;
        };

        // Country paths
        g.selectAll("path.da-country")
          .data(land.features)
          .enter().append("path")
          .attr("class", "da-country")
          .attr("d", pathGen)
          .attr("fill", (d) => lookup(d) ? "#1B2742" : "#16203A")
          .attr("stroke", "rgba(168, 152, 128, 0.22)")
          .attr("stroke-width", 0.35)
          .style("cursor", (d) => lookup(d) ? "pointer" : "default")
          .style("transition", "fill 220ms ease")
          .on("mouseenter", function (e, d) {
            const c = lookup(d);
            d3.select(this).attr("fill", "rgba(201, 168, 76, 0.20)");
            const rectWrap = wrapRef.current.getBoundingClientRect();
            setTooltip({
              x: e.clientX - rectWrap.left + 14,
              y: e.clientY - rectWrap.top + 14,
              country: c,
              name: (d.properties && d.properties.name) || "País",
            });
          })
          .on("mousemove", function (e) {
            const rectWrap = wrapRef.current.getBoundingClientRect();
            setTooltip((t) => t ? { ...t, x: e.clientX - rectWrap.left + 14, y: e.clientY - rectWrap.top + 14 } : null);
          })
          .on("mouseleave", function (e, d) {
            const c = lookup(d);
            d3.select(this).attr("fill", c ? "#1B2742" : "#16203A");
            setTooltip(null);
          })
          .on("click", function (e, d) {
            const c = lookup(d);
            if (c) setSelected(c);
          });

        // Animated markers
        const markerG = g.append("g").attr("class", "da-markers");
        COUNTRIES.forEach((c) => {
          const feat = land.features.find((f) => {
            const idKey = String(parseInt(f.id, 10));
            if (idKey === String(parseInt(c.id, 10))) return true;
            const name = (f.properties && f.properties.name || "").toLowerCase();
            return (NAME_FALLBACK[c.id] || []).some((n) => n.toLowerCase() === name);
          });
          if (!feat) return;
          const [cx, cy] = pathGen.centroid(feat);
          if (isNaN(cx) || isNaN(cy)) return;

          const maxCount = 87;
          const r = 4 + (c.count / maxCount) * 6;

          const m = markerG.append("g")
            .attr("class", "da-marker")
            .attr("data-region", c.region)
            .attr("transform", `translate(${cx}, ${cy})`)
            .style("cursor", "pointer")
            .on("click", (e) => { e.stopPropagation(); setSelected(c); });

          // Outer pulse ring (animated via SVG <animate>)
          const ring = m.append("circle")
            .attr("class", "da-marker-pulse")
            .attr("r", r)
            .attr("fill", "none")
            .attr("stroke", c.color)
            .attr("stroke-width", 1.2)
            .attr("opacity", 0.65);
          ring.append("animate")
            .attr("attributeName", "r")
            .attr("values", `${r};${r * 2.6}`)
            .attr("dur", "2.4s")
            .attr("repeatCount", "indefinite");
          ring.append("animate")
            .attr("attributeName", "opacity")
            .attr("values", "0.7;0")
            .attr("dur", "2.4s")
            .attr("repeatCount", "indefinite");

          // Filled dot with glow
          m.append("circle")
            .attr("class", "da-marker-dot")
            .attr("r", r * 0.55)
            .attr("fill", c.color)
            .attr("filter", "url(#da-glow)");

          // Hover handler on marker for tooltip
          m.on("mouseenter", function (e) {
            const rectWrap = wrapRef.current.getBoundingClientRect();
            setTooltip({
              x: e.clientX - rectWrap.left + 14,
              y: e.clientY - rectWrap.top + 14,
              country: c,
              name: c.name,
            });
          })
          .on("mousemove", function (e) {
            const rectWrap = wrapRef.current.getBoundingClientRect();
            setTooltip((t) => t ? { ...t, x: e.clientX - rectWrap.left + 14, y: e.clientY - rectWrap.top + 14 } : null);
          })
          .on("mouseleave", function () { setTooltip(null); });
        });

        // Zoom
        const zoom = d3.zoom()
          .scaleExtent([1, 6])
          .translateExtent([[-50, -50], [width + 50, height + 50]])
          .on("zoom", (e) => g.attr("transform", e.transform));
        svg.call(zoom);
        svg.on("dblclick.zoom", null); // disable double-click zoom (feels annoying)
        zoomRef.current = zoom;
      })
      .catch((e) => { if (!cancelled) setError("No se pudo cargar el mapa: " + e.message); });

    return () => { cancelled = true; };
  }, [ready, idMap, nameMap]);

  /* Region filter — update marker opacity */
  useEffectM(() => {
    if (!gRef.current) return;
    gRef.current.selectAll(".da-marker").style("opacity", function () {
      const r = this.getAttribute("data-region");
      if (region === "all") return 1;
      return r === region ? 1 : 0.18;
    });
  }, [region]);

  const zoomIn = () => {
    if (!zoomRef.current || !svgRef.current) return;
    window.d3.select(svgRef.current).transition().duration(300).call(zoomRef.current.scaleBy, 1.6);
  };
  const zoomOut = () => {
    if (!zoomRef.current || !svgRef.current) return;
    window.d3.select(svgRef.current).transition().duration(300).call(zoomRef.current.scaleBy, 1 / 1.6);
  };
  const zoomReset = () => {
    if (!zoomRef.current || !svgRef.current) return;
    window.d3.select(svgRef.current).transition().duration(450).call(zoomRef.current.transform, window.d3.zoomIdentity);
  };

  const REGIONS = [
    { id: "all", label: "Todos" },
    { id: "America", label: "América" },
    { id: "Europe", label: "Europa" },
    { id: "Asia", label: "Asia" },
    { id: "Africa", label: "África" },
    { id: "Oceania", label: "Oceanía" },
  ];

  return (
    <main className="da-explore">
      <div className="da-explore-head">
        <button className="da-back" onClick={onBack}>
          <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M16 10H4M9 5L4 10l5 5"/>
          </svg>
          Inicio
        </button>
        <div className="da-overline">EXPLORAR · MAPA INTERACTIVO</div>
        <h1 className="da-explore-h1">
          Todo el mundo, <em>por país.</em>
        </h1>
        <p className="da-explore-sub">
          Haz click en cualquier país iluminado para ver las recetas, técnicas e ingredientes que hemos publicado.
        </p>
      </div>

      {/* Region filter */}
      <div className="da-region-filter">
        {REGIONS.map((r) => (
          <button
            key={r.id}
            className={`da-pill ${region === r.id ? "is-active" : ""}`}
            onClick={() => setRegion(r.id)}
          >
            {r.label}
          </button>
        ))}
      </div>

      <div className="da-map-wrap" ref={wrapRef}>
        <svg ref={svgRef} className="da-map" aria-label="Mapa mundial interactivo"></svg>

        {!ready && !error && (
          <div className="da-map-loading">
            <span className="da-loader" aria-hidden="true"></span>
            Cargando atlas…
          </div>
        )}
        {error && (
          <div className="da-map-error">
            {error}
          </div>
        )}

        {/* Tooltip */}
        {tooltip && (
          <div className="da-tooltip" style={{ left: tooltip.x, top: tooltip.y }}>
            {tooltip.country ? (
              <>
                <div className="da-ttip-name">
                  <span className="da-ttip-flag">{tooltip.country.flag}</span>
                  {tooltip.country.name}
                </div>
                <div className="da-ttip-meta" style={{ color: tooltip.country.color }}>
                  {tooltip.country.count} artículos
                </div>
                <div className="da-ttip-hint">Click para ver →</div>
              </>
            ) : (
              <>
                <div className="da-ttip-name">{tooltip.name}</div>
                <div className="da-ttip-meta da-ttip-meta--empty">Sin artículos aún</div>
              </>
            )}
          </div>
        )}

        {/* Controls — bottom-left */}
        <div className="da-map-controls">
          <button onClick={zoomIn} aria-label="Acercar">+</button>
          <button onClick={zoomOut} aria-label="Alejar">−</button>
          <button onClick={zoomReset} aria-label="Restablecer" className="da-zc-reset">⤾</button>
        </div>

        {/* Legend — bottom-right */}
        <div className="da-map-legend">
          <div className="da-legend-row">
            <span className="da-legend-marker"></span>
            <span>Países con contenido</span>
          </div>
          <div className="da-legend-row">
            <span className="da-legend-tile"></span>
            <span>Aún sin artículos</span>
          </div>
        </div>
      </div>

      {/* Country tally row below */}
      <div className="da-tally">
        <div className="da-tally-inner">
          <div className="da-tally-count">
            <span className="da-tally-num">{COUNTRIES.length}</span>
            <span className="da-tally-lbl">países con contenido publicado</span>
          </div>
          <div className="da-tally-list">
            {COUNTRIES.slice(0, 8).map((c) => (
              <button
                key={c.id}
                className="da-tally-chip"
                style={{ "--c": c.color }}
                onClick={() => setSelected(c)}
              >
                <span>{c.flag}</span>
                {c.name}
                <span className="da-tally-num-sm">{c.count}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Side panel */}
      <CountryPanel country={selected} onClose={() => setSelected(null)} />
    </main>
  );
}

Object.assign(window, { ExplorePage });

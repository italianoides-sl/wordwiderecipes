/* worldwiderecipes.app — Dark Atlas exploration
   Country roster + sample articles (all mocked, no backend) */

const COUNTRIES = [
  { id: "484", name: "México",        flag: "🇲🇽", count: 87, color: "#1FBFB8", region: "America", capital: "Norteamérica" },
  { id: "724", name: "España",        flag: "🇪🇸", count: 73, color: "#9C1F4A", region: "Europe",  capital: "Europa Occidental" },
  { id: "392", name: "Japón",         flag: "🇯🇵", count: 64, color: "#C9A84C", region: "Asia",    capital: "Asia Oriental" },
  { id: "356", name: "India",         flag: "🇮🇳", count: 61, color: "#C9A84C", region: "Asia",    capital: "Asia Meridional" },
  { id: "156", name: "China",         flag: "🇨🇳", count: 56, color: "#C9A84C", region: "Asia",    capital: "Asia Oriental" },
  { id: "380", name: "Italia",        flag: "🇮🇹", count: 58, color: "#C9A84C", region: "Europe",  capital: "Europa Mediterránea" },
  { id: "250", name: "Francia",       flag: "🇫🇷", count: 52, color: "#B890D8", region: "Europe",  capital: "Europa Occidental" },
  { id: "604", name: "Perú",          flag: "🇵🇪", count: 45, color: "#E8457A", region: "America", capital: "Sudamérica" },
  { id: "764", name: "Tailandia",     flag: "🇹🇭", count: 43, color: "#1FBFB8", region: "Asia",    capital: "Sudeste Asiático" },
  { id: "076", name: "Brasil",        flag: "🇧🇷", count: 41, color: "#6DC882", region: "America", capital: "Sudamérica" },
  { id: "504", name: "Marruecos",     flag: "🇲🇦", count: 38, color: "#C9A84C", region: "Africa",  capital: "Norte de África" },
  { id: "032", name: "Argentina",     flag: "🇦🇷", count: 35, color: "#1FBFB8", region: "America", capital: "Sudamérica" },
  { id: "410", name: "Corea del Sur", flag: "🇰🇷", count: 37, color: "#E8457A", region: "Asia",    capital: "Asia Oriental" },
  { id: "300", name: "Grecia",        flag: "🇬🇷", count: 39, color: "#B890D8", region: "Europe",  capital: "Europa Mediterránea" },
  { id: "792", name: "Turquía",       flag: "🇹🇷", count: 34, color: "#C9A84C", region: "Asia",    capital: "Anatolia" },
  { id: "704", name: "Vietnam",       flag: "🇻🇳", count: 31, color: "#6DC882", region: "Asia",    capital: "Sudeste Asiático" },
  { id: "170", name: "Colombia",      flag: "🇨🇴", count: 28, color: "#E8457A", region: "America", capital: "Sudamérica" },
  { id: "276", name: "Alemania",      flag: "🇩🇪", count: 27, color: "#1FBFB8", region: "Europe",  capital: "Europa Central" },
  { id: "231", name: "Etiopía",       flag: "🇪🇹", count: 24, color: "#C9A84C", region: "Africa",  capital: "Cuerno de África" },
];

const TYPE_META = {
  receta:      { label: "Receta",      color: "#E8457A", icon: "🍳" },
  tecnica:     { label: "Técnica",     color: "#1FBFB8", icon: "🔪" },
  ingrediente: { label: "Ingrediente", color: "#6DC882", icon: "🌿" },
  guia:        { label: "Guía",        color: "#B890D8", icon: "📖" },
  especia:     { label: "Especia",     color: "#C9A84C", icon: "🌶️" },
  cocina:      { label: "Cocina",      color: "#C9A84C", icon: "🗺️" },
};

const ARTICLES_BY_COUNTRY = {
  "484": [ /* México */
    { t: "Pozole rojo de Guerrero",                  k: "receta",      time: "3 h 20 min" },
    { t: "Mole negro de Oaxaca, paso a paso",        k: "receta",      time: "5 h" },
    { t: "Nixtamalización casera del maíz",          k: "tecnica",     time: "12 h reposo" },
    { t: "Chile guajillo · perfil y usos",           k: "ingrediente", time: "Lectura 6 min" },
    { t: "Ruta del mezcal por Oaxaca",               k: "guia",        time: "Lectura 14 min" },
    { t: "Tacos al pastor sin trompo",               k: "receta",      time: "2 h 30 min" },
    { t: "Cocina prehispánica · una introducción",   k: "cocina",      time: "Lectura 10 min" },
  ],
  "724": [ /* España */
    { t: "Paella valenciana, la de verdad",          k: "receta",      time: "1 h 40 min" },
    { t: "Tortilla de patatas con cebolla pochada",  k: "receta",      time: "55 min" },
    { t: "Sofrito · la base de todo",                k: "tecnica",     time: "45 min" },
    { t: "Pimentón de la Vera",                      k: "especia",     time: "Lectura 5 min" },
    { t: "Pintxos de San Sebastián · ruta",          k: "guia",        time: "Lectura 12 min" },
    { t: "Cocido madrileño en tres vuelcos",         k: "receta",      time: "3 h" },
    { t: "Jamón ibérico · cortes y servicio",        k: "tecnica",     time: "Lectura 8 min" },
  ],
  "392": [ /* Japón */
    { t: "Dashi de katsuobushi y kombu",             k: "tecnica",     time: "25 min" },
    { t: "Ramen tonkotsu de 18 horas",               k: "receta",      time: "18 h" },
    { t: "Sushi · arroz, vinagre, paciencia",        k: "tecnica",     time: "Lectura 9 min" },
    { t: "Miso · variedades y maduración",           k: "ingrediente", time: "Lectura 7 min" },
    { t: "Wasabi real vs. rábano picante",           k: "ingrediente", time: "Lectura 4 min" },
    { t: "Cocina kaiseki · una introducción",        k: "cocina",      time: "Lectura 11 min" },
  ],
  "356": [ /* India */
    { t: "Biryani de Hyderabad",                     k: "receta",      time: "2 h 20 min" },
    { t: "Garam masala casero, tostado y molido",    k: "especia",     time: "20 min" },
    { t: "Tarka · la técnica del aceite",            k: "tecnica",     time: "10 min" },
    { t: "Cardamomo verde · el rey",                 k: "especia",     time: "Lectura 4 min" },
    { t: "Cocina del sur · dosa y sambar",           k: "cocina",      time: "Lectura 8 min" },
  ],
  "380": [ /* Italia */
    { t: "Cacio e pepe sin que se corte",            k: "receta",      time: "20 min" },
    { t: "Pasta fresca al huevo · tagliatelle",      k: "tecnica",     time: "1 h" },
    { t: "Pizza napoletana · la masa",               k: "tecnica",     time: "48 h reposo" },
    { t: "Aceite de oliva · cómo catarlo",           k: "guia",        time: "Lectura 7 min" },
    { t: "Tiramisú clásico",                         k: "receta",      time: "35 min + frío" },
  ],
};

/* Generic placeholder articles for any country we click that's not in the map above */
function placeholderArticlesFor(country) {
  return [
    { t: `Plato icónico de ${country.name}`,           k: "receta",      time: "1 h" },
    { t: `Técnica tradicional · ${country.name}`,      k: "tecnica",     time: "Lectura 6 min" },
    { t: `Ingrediente clave de ${country.name}`,       k: "ingrediente", time: "Lectura 5 min" },
    { t: `Una introducción a la cocina ${country.name}`, k: "cocina",    time: "Lectura 9 min" },
  ];
}

/* Type breakdown — fake counts per type derived from total */
function typeBreakdown(total) {
  const recetas      = Math.round(total * 0.42);
  const tecnicas     = Math.round(total * 0.18);
  const ingredientes = Math.round(total * 0.16);
  const guias        = Math.round(total * 0.10);
  const especias     = Math.round(total * 0.08);
  const cocina       = Math.max(1, total - recetas - tecnicas - ingredientes - guias - especias);
  return [
    { key: "receta",      count: recetas },
    { key: "tecnica",     count: tecnicas },
    { key: "ingrediente", count: ingredientes },
    { key: "guia",        count: guias },
    { key: "especia",     count: especias },
    { key: "cocina",      count: cocina },
  ];
}

/* Export to window for sibling Babel scripts */
Object.assign(window, {
  COUNTRIES,
  TYPE_META,
  ARTICLES_BY_COUNTRY,
  placeholderArticlesFor,
  typeBreakdown,
});

/* worldwiderecipes.app — Dark Atlas · App + Nav
   Top-level component, sticky nav, page switching */

const { useState: useStateA, useEffect: useEffectA } = React;

function Nav({ page, setPage }) {
  const [mobileOpen, setMobileOpen] = useStateA(false);
  const links = [
    { id: "home",    label: "Inicio",      page: "home" },
    { id: "explore", label: "🌐 Explorar", page: "explore" },
    { id: "recipes", label: "Recetas",     page: "home" },
  ];

  return (
    <header className="da-nav">
      <div className="da-nav-inner">
        <a
          href="#"
          className="da-logo"
          onClick={(e) => { e.preventDefault(); setPage("home"); setMobileOpen(false); }}
        >
          <span className="da-logo-globe">🌍</span>
          <span>WorldWideRecipes</span>
        </a>

        <nav className={`da-nav-links ${mobileOpen ? "is-open" : ""}`} aria-label="Principal">
          {links.map((l) => (
            <a
              key={l.id}
              href="#"
              className={`da-nav-link ${page === l.page && l.id !== "recipes" ? "is-active" : ""}`}
              onClick={(e) => { e.preventDefault(); setPage(l.page); setMobileOpen(false); }}
            >
              {l.label}
            </a>
          ))}
          <a
            href="https://www.tiktok.com/@tuvirtualchef"
            target="_blank"
            rel="noopener"
            className="da-nav-link da-nav-link--tt"
          >
            @tuvirtualchef ↗
          </a>
        </nav>

        <button
          className={`da-burger ${mobileOpen ? "is-open" : ""}`}
          aria-label="Menú"
          onClick={() => setMobileOpen((v) => !v)}
        >
          <span></span><span></span><span></span>
        </button>
      </div>
    </header>
  );
}

function App() {
  const [page, setPage] = useStateA("home");

  // Scroll to top on page change
  useEffectA(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [page]);

  return (
    <>
      <Nav page={page} setPage={setPage} />
      {page === "home"
        ? <HomePage onExplore={() => setPage("explore")} />
        : <ExplorePage onBack={() => setPage("home")} />}
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);

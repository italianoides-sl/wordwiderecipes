/* worldwiderecipes.app — TikTok CTA component
   Variants: <TikTokCTAFull/>, <TikTokCTAMini/> */

const { useEffect, useRef, useState } = React;

/* ============================================================
   Scroll-into-view hook — adds .is-visible when intersected
   ============================================================ */
function useInView({ threshold = 0.18, once = true } = {}) {
  const ref = useRef(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    // Reduced motion: show immediately
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setInView(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setInView(true);
            if (once) io.unobserve(el);
          } else if (!once) {
            setInView(false);
          }
        });
      },
      { threshold }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold, once]);

  return [ref, inView];
}

/* ============================================================
   TikTok logo
   ============================================================ */
function TikTokLogo({ className = "" }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43V8.55a8.16 8.16 0 0 0 4.77 1.52V6.69h-1.84z"/>
    </svg>
  );
}

/* ============================================================
   Phone mockup — TikTok PHOTO CAROUSEL (slideshow post)
   Shows 4 "slides" of a recipe technique, auto-advancing.
   ============================================================ */
function PhoneMockup({ caption, handle, recipeTitle, slides }) {
  const defaultSlides = [
    { kicker: "Paso 1 · 8 seg",  title: "Tuesta los chiles",     tone: "ember"   },
    { kicker: "Paso 2 · 12 seg", title: "Hidrata 20 min",        tone: "broth"   },
    { kicker: "Paso 3 · 15 seg", title: "Licúa con caldo",       tone: "sauce"   },
    { kicker: "Paso 4 · 10 seg", title: "Sofríe hasta oscurecer", tone: "deep"   },
  ];
  const data = slides || defaultSlides;

  const [active, setActive] = useState(0);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = setInterval(() => setActive((i) => (i + 1) % data.length), 2200);
    return () => clearInterval(t);
  }, [data.length]);

  return (
    <div className="ttc-phone-stage" aria-hidden="true">
      <div className="ttc-phone-glow"></div>
      <div className="ttc-phone-bg"></div>
      <div className="ttc-phone">
        <div className="ttc-phone-bezel">
          <div className="ttc-phone-notch"></div>
          <div className="ttc-phone-screen">
            <div className="ttc-video">
              {/* Slides — only one visible at a time */}
              {data.map((s, i) => (
                <div
                  key={i}
                  className={`ttc-slide ttc-slide--${s.tone} ${i === active ? "is-active" : ""}`}
                >
                  <div className="ttc-slide-bg"></div>
                  <div className="ttc-slide-grain"></div>
                  <svg className="ttc-slide-art" viewBox="0 0 200 280" preserveAspectRatio="xMidYMid slice">
                    {s.tone === "ember" && <SlideArtEmber />}
                    {s.tone === "broth" && <SlideArtBroth />}
                    {s.tone === "sauce" && <SlideArtSauce />}
                    {s.tone === "deep"  && <SlideArtDeep />}
                  </svg>
                  <div className="ttc-slide-label">
                    <div className="ttc-slide-kicker">{s.kicker}</div>
                    <div className="ttc-slide-title">{s.title}</div>
                  </div>
                </div>
              ))}

              {/* "Foto" badge — top-left (TikTok photo post indicator) */}
              <div className="ttc-photo-badge">
                <svg viewBox="0 0 14 14" fill="currentColor" aria-hidden="true">
                  <rect x="1.5" y="3" width="11" height="8" rx="1.2" fill="none" stroke="currentColor" strokeWidth="1.2"/>
                  <circle cx="5" cy="7" r="1.2"/>
                  <path d="M2 11l3-3 2 2 3-3 2 2v2H2z" />
                </svg>
                <span>Foto</span>
              </div>

              {/* Slide counter top-right */}
              <div className="ttc-slide-counter">
                <span>{active + 1}</span>
                <span className="sep">/</span>
                <span>{data.length}</span>
              </div>

              {/* Side rail */}
              <div className="ttc-rail">
                <div className="ttc-rail-avatar"></div>
                <div className="ttc-rail-item">
                  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21s-7-4.5-9.5-9.2C.7 8.4 2.4 5 5.5 5c1.9 0 3.6 1 4.5 2.5C10.9 6 12.6 5 14.5 5c3.1 0 4.8 3.4 3 6.8C19 16.5 12 21 12 21z"/></svg>
                  <span>4.2K</span>
                </div>
                <div className="ttc-rail-item">
                  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.7 8.5 8.5 0 0 1-7.6 4.8 8.4 8.4 0 0 1-3.7-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.8-7.6 8.4 8.4 0 0 1 3.7-.9h.5a8.5 8.5 0 0 1 8 8z"/></svg>
                  <span>189</span>
                </div>
                <div className="ttc-rail-item">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 5h11l-3-3M19 19H8l3 3"/></svg>
                  <span>Guardar</span>
                </div>
              </div>

              {/* Bottom caption */}
              <div className="ttc-caption">
                <div className="ttc-handle">{handle}</div>
                <div className="ttc-cap-text">{caption || recipeTitle}</div>
                <div className="ttc-music">
                  <svg viewBox="0 0 16 16" fill="currentColor"><path d="M13 2v9.5a2.5 2.5 0 1 1-1-2V4l-7 1v8.5A2.5 2.5 0 1 1 4 11.5V3l9-1z"/></svg>
                  <span>4 fotos · desliza para ver</span>
                </div>
              </div>

              {/* Dots — slide indicator */}
              <div className="ttc-dots">
                {data.map((_, i) => (
                  <span key={i} className={`ttc-dot ${i === active ? "is-active" : ""}`}></span>
                ))}
              </div>
            </div>
          </div>
        </div>
        <div className="ttc-phone-button-side"></div>
        <div className="ttc-phone-button-vol-up"></div>
        <div className="ttc-phone-button-vol-down"></div>
      </div>
    </div>
  );
}

/* ============================================================
   Slide art — abstract food illustrations per step
   ============================================================ */
function SlideArtEmber() {
  return (
    <g>
      {/* Sartén seca + chiles tostándose */}
      <ellipse cx="100" cy="170" rx="78" ry="14" fill="rgba(0,0,0,0.45)"/>
      <ellipse cx="100" cy="166" rx="72" ry="10" fill="#2A1208"/>
      {[...Array(5)].map((_, i) => {
        const x = 60 + i * 18;
        const r = 22 + (i % 2) * 4;
        return (
          <g key={i} transform={`translate(${x} ${162}) rotate(${-15 + i * 8})`}>
            <ellipse cx="0" cy="0" rx={r/2} ry="4" fill="#6E2A1A"/>
            <ellipse cx="0" cy="-1" rx={r/2 - 2} ry="2.5" fill="#C4533A"/>
          </g>
        );
      })}
      {/* humo */}
      <g stroke="rgba(255,255,255,0.22)" strokeWidth="1.3" fill="none" strokeLinecap="round">
        <path d="M75 140 Q 82 120 76 100"/>
        <path d="M110 140 Q 118 115 112 95"/>
        <path d="M135 145 Q 140 125 134 108"/>
      </g>
    </g>
  );
}
function SlideArtBroth() {
  return (
    <g>
      {/* Bol con chiles hidratándose */}
      <ellipse cx="100" cy="200" rx="80" ry="20" fill="rgba(0,0,0,0.4)"/>
      <path d="M30 160 Q 30 220 100 220 Q 170 220 170 160 Z" fill="#1C1410"/>
      <ellipse cx="100" cy="160" rx="70" ry="14" fill="#8B3A1F"/>
      <ellipse cx="100" cy="158" rx="62" ry="9" fill="#C4533A" opacity="0.85"/>
      {/* chiles flotando */}
      {[...Array(4)].map((_, i) => (
        <ellipse
          key={i}
          cx={70 + i * 20}
          cy={158 - (i % 2) * 2}
          rx="9" ry="3"
          fill="#3a1612"
          opacity="0.7"
        />
      ))}
      {/* gotas / reflejo */}
      <circle cx="80" cy="155" r="2" fill="rgba(255,255,255,0.3)"/>
      <circle cx="130" cy="156" r="1.5" fill="rgba(255,255,255,0.25)"/>
    </g>
  );
}
function SlideArtSauce() {
  return (
    <g>
      {/* Vaso de licuadora con salsa roja */}
      <rect x="62" y="60" width="76" height="160" rx="6" fill="#1a1311" stroke="rgba(255,255,255,0.1)" strokeWidth="1"/>
      <rect x="66" y="100" width="68" height="115" rx="3" fill="#8B3A1F"/>
      <rect x="66" y="100" width="68" height="115" rx="3" fill="url(#sauceGrad)"/>
      <defs>
        <linearGradient id="sauceGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#E8A838" stopOpacity="0.4"/>
          <stop offset="50%" stopColor="#C4533A" stopOpacity="0.1"/>
          <stop offset="100%" stopColor="#6E2A1A" stopOpacity="0.5"/>
        </linearGradient>
      </defs>
      {/* burbujitas */}
      <circle cx="82" cy="115" r="3" fill="rgba(232,168,56,0.55)"/>
      <circle cx="105" cy="125" r="2" fill="rgba(232,168,56,0.4)"/>
      <circle cx="120" cy="108" r="2.5" fill="rgba(232,168,56,0.45)"/>
      {/* tapa */}
      <rect x="58" y="56" width="84" height="10" rx="3" fill="#2A1E18"/>
      <circle cx="100" cy="50" r="6" fill="#2A1E18"/>
    </g>
  );
}
function SlideArtDeep() {
  return (
    <g>
      {/* Olla con salsa sofriéndose */}
      <ellipse cx="100" cy="220" rx="90" ry="15" fill="rgba(0,0,0,0.5)"/>
      <rect x="38" y="135" width="124" height="80" rx="4" fill="#1a0e08"/>
      <rect x="22" y="155" width="18" height="8" rx="2" fill="#1a0e08"/>
      <rect x="160" y="155" width="18" height="8" rx="2" fill="#1a0e08"/>
      <ellipse cx="100" cy="138" rx="62" ry="10" fill="#3a1208"/>
      <ellipse cx="100" cy="137" rx="56" ry="7" fill="#6E2A1A"/>
      {/* superficie con brillo */}
      <ellipse cx="92" cy="135" rx="20" ry="2" fill="rgba(232,168,56,0.5)"/>
      {/* vapor caliente */}
      <g stroke="rgba(255,255,255,0.2)" strokeWidth="1.4" fill="none" strokeLinecap="round">
        <path d="M75 110 Q 80 90 75 70"/>
        <path d="M100 105 Q 105 85 100 65"/>
        <path d="M125 110 Q 130 90 125 70"/>
      </g>
    </g>
  );
}

/* ============================================================
   <TikTokCTAFull/> — full immersive band
   ============================================================ */
function TikTokCTAFull({
  handle = "@tuvirtualchef",
  headline = "Aprende a cocinar en menos de un minuto.",
  subline = "Recetas y técnicas en fotos — desliza, lee, cocina. Una nueva cada semana en @tuvirtualchef.",
  hashtags = ["#cocinaen60s", "#técnicasdecocina", "#recetasrápidas", "#tuvirtualchef"],
  ctaLabel = "Seguir en TikTok",
  stats = [
    { value: "30K+",   label: "seguidores" },
    { value: "120",    label: "recetas en foto" },
    { value: "<1 min", label: "por receta" },
  ],
  recipeTitle = "Pozole rojo de Guerrero",
  videoCaption = "Pozole rojo paso a paso 🌽 desliza para ver la técnica",
  url = "https://www.tiktok.com/@tuvirtualchef",
  slides,
}) {
  const [ref, inView] = useInView({ threshold: 0.2 });

  return (
    <section
      ref={ref}
      className={`ttc ttc-full ${inView ? "is-visible" : ""}`}
      aria-labelledby="ttc-headline"
    >
      {/* Top accent spine */}
      <div className="ttc-spine" aria-hidden="true"></div>

      {/* Decorative noise + glow */}
      <div className="ttc-bg-decor" aria-hidden="true">
        <div className="ttc-bg-glow ttc-bg-glow-1"></div>
        <div className="ttc-bg-glow ttc-bg-glow-2"></div>
      </div>

      <div className="ttc-inner">
        {/* LEFT — phone */}
        <div className="ttc-col-phone ttc-stagger" style={{ "--i": 1 }}>
          <PhoneMockup
            caption={videoCaption}
            handle={handle}
            recipeTitle={recipeTitle}
            slides={slides}
          />
        </div>

        {/* CENTER — copy */}
        <div className="ttc-col-copy">
          <span className="ttc-overline ttc-stagger" style={{ "--i": 2 }}>
            <span className="ttc-overline-dot" aria-hidden="true"></span>
            FOTO-RECETAS · 60 SEG
          </span>

          <h2 className="ttc-headline ttc-stagger" id="ttc-headline" style={{ "--i": 3 }}>
            {headline}
          </h2>

          <p className="ttc-subline ttc-stagger" style={{ "--i": 4 }}>
            {subline}
          </p>

          <div className="ttc-hashtags ttc-stagger" style={{ "--i": 5 }}>
            {hashtags.map((h) => (
              <a key={h} className="ttc-hashtag" href={`#/tiktok/tag/${h.replace("#", "")}`}>
                {h}
              </a>
            ))}
          </div>

          <a className="ttc-cta ttc-stagger" href={url} target="_blank" rel="noopener" style={{ "--i": 6 }}>
            <TikTokLogo className="ttc-cta-logo"/>
            <span>{ctaLabel}</span>
            <svg className="ttc-cta-arrow" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M4 10h12M11 5l5 5-5 5"/>
            </svg>
          </a>
        </div>

        {/* RIGHT — stats */}
        <div className="ttc-col-stats ttc-stagger" style={{ "--i": 4 }}>
          <ul className="ttc-stats">
            {stats.map((s, i) => (
              <li key={i}>
                <span className="ttc-stat-value">{s.value}</span>
                <span className="ttc-stat-label">{s.label}</span>
              </li>
            ))}
          </ul>
          <div className="ttc-handle-row">
            <span className="ttc-handle-tag">{handle}</span>
            <span className="ttc-handle-verified" aria-label="Cuenta verificada">
              <svg viewBox="0 0 12 12" fill="currentColor"><path d="M6 0L7.4 1.4 9.3 1l.7 2L12 4.2l-1 1.8L12 7.8 10 9l-.7 2-1.9-.4L6 12 4.6 10.6 2.7 11 2 9 0 7.8 1 6 0 4.2 2 3l.7-2 1.9.4L6 0zm2.3 4.3L5 7.6 3.7 6.3 3 7l2 2 4-4-.7-.7z"/></svg>
            </span>
          </div>
          <span className="ttc-cyan-tag">Sonido original</span>
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   <TikTokCTAMini/> — compact sidebar version
   ============================================================ */
function TikTokCTAMini({
  handle = "@tuvirtualchef",
  text = "Receta en fotos, menos de 1 minuto.",
  url = "https://www.tiktok.com/@tuvirtualchef",
}) {
  const [ref, inView] = useInView({ threshold: 0.4 });

  return (
    <a
      ref={ref}
      href={url}
      target="_blank"
      rel="noopener"
      className={`ttc ttc-mini ${inView ? "is-visible" : ""}`}
    >
      <span className="ttc-spine" aria-hidden="true"></span>
      <span className="ttc-mini-icon">
        <TikTokLogo />
      </span>
      <span className="ttc-mini-copy">
        <span className="ttc-mini-overline">FOTO-RECETAS · &lt;1 MIN</span>
        <span className="ttc-mini-text">{text}</span>
        <span className="ttc-mini-handle">{handle}</span>
      </span>
      <span className="ttc-mini-cta" aria-hidden="true">
        Ver
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 8h10M9 4l4 4-4 4"/>
        </svg>
      </span>
    </a>
  );
}

/* Export */
Object.assign(window, { TikTokCTAFull, TikTokCTAMini, useInView });

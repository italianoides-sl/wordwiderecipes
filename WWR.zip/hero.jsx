/* worldwiderecipes.app — Homepage Hero
   Editorial hero: featured + 2 stacked + trending bar
   Copy in castellano */

const { useState, useEffect, useRef } = React;

/* ---------- Sample data ---------- */
const HERO_RECIPES = {
  featured: {
    id: "paella-valenciana",
    title: "Paella valenciana original, con caracoles y bajoqueta",
    kicker: "Receta del día · Domingo",
    cuisine: { flag: "🇪🇸", name: "España · Valencia", code: "es" },
    time: "1 h 20 min",
    difficulty: "Medio",
    servings: "6 raciones",
    image: "https://images.unsplash.com/photo-1534080564583-6be75777b70a?auto=format&fit=crop&w=1600&q=80",
    excerpt: "La auténtica, la de los huertos de Valencia: conejo, pollo de corral, garrofó, judía verde y un buen sofrito de tomate. Sin marisco, sin chorizo, sin discusión.",
    author: "Lucía García",
    views: "12.4k",
  },
  secondary: [
    {
      id: "cochinita-pibil",
      title: "Cochinita pibil al estilo yucateco",
      cuisine: { flag: "🇲🇽", name: "México · Yucatán", code: "mx" },
      time: "4 h",
      difficulty: "Avanzado",
      image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&w=1200&q=80",
      excerpt: "Carne de cerdo marinada en achiote y naranja agria, envuelta en hoja de plátano.",
    },
    {
      id: "gazpacho-andaluz",
      title: "Gazpacho andaluz de tomates de la huerta",
      cuisine: { flag: "🇪🇸", name: "España · Andalucía", code: "es" },
      time: "20 min",
      difficulty: "Fácil",
      image: "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=1200&q=80",
      excerpt: "Frío, espeso, con un chorro de aceite virgen extra y unos picatostes.",
    },
  ],
};

const TRENDING_PILLS = [
  { flag: "🇪🇸", label: "Cocina española", count: 412 },
  { flag: "🇲🇽", label: "Cocina mexicana", count: 387 },
  { flag: "🇵🇪", label: "Cocina peruana", count: 156 },
  { flag: "🇦🇷", label: "Asado argentino", count: 92 },
  { flag: "🇨🇴", label: "Cocina colombiana", count: 78 },
  { flag: "🇮🇹", label: "Pasta italiana", count: 245 },
  { flag: "🇯🇵", label: "Ramen y sushi", count: 198 },
  { flag: "🇹🇭", label: "Comida tailandesa", count: 134 },
];

/* ---------- Cuisine badge ---------- */
function CuisineBadge({ flag, name, size = "md" }) {
  const padding = size === "sm" ? "5px 9px" : "6px 11px";
  const fontSize = size === "sm" ? "10px" : "11px";
  return (
    <span className="wwr-cuisine-badge" style={{ padding, fontSize }}>
      <span className="wwr-cb-flag" aria-hidden="true">{flag}</span>
      <span className="wwr-cb-name">{name}</span>
    </span>
  );
}

/* ---------- Recipe card ---------- */
function FeaturedCard({ recipe }) {
  return (
    <article className="wwr-card wwr-card--featured" data-cuisine={recipe.cuisine.code}>
      <a className="wwr-card-link" href={`#/recipe/${recipe.id}`}>
        <div className="wwr-card-media">
          <img className="wwr-card-img wwr-parallax-img" src={recipe.image} alt={recipe.title} />
          <div className="wwr-card-overlay"></div>
          <div className="wwr-card-top">
            <CuisineBadge flag={recipe.cuisine.flag} name={recipe.cuisine.name} />
            <span className="wwr-kicker">{recipe.kicker}</span>
          </div>
          <div className="wwr-card-body wwr-card-body--featured">
            <div className="wwr-meta">
              <span>{recipe.time}</span>
              <span aria-hidden="true">·</span>
              <span>{recipe.difficulty}</span>
              <span aria-hidden="true">·</span>
              <span>{recipe.servings}</span>
              <span aria-hidden="true">·</span>
              <span>{recipe.views} vistas</span>
            </div>
            <h1 className="wwr-card-title wwr-card-title--featured">
              {recipe.title}
            </h1>
            <p className="wwr-card-excerpt">{recipe.excerpt}</p>
            <div className="wwr-card-footer">
              <span className="wwr-cta">
                Ver receta
                <svg className="wwr-cta-arrow" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M4 10h12M11 5l5 5-5 5"/>
                </svg>
              </span>
              <span className="wwr-author">por {recipe.author}</span>
            </div>
          </div>
        </div>
      </a>
    </article>
  );
}

function SecondaryCard({ recipe }) {
  return (
    <article className="wwr-card wwr-card--secondary" data-cuisine={recipe.cuisine.code}>
      <a className="wwr-card-link" href={`#/recipe/${recipe.id}`}>
        <div className="wwr-card-media">
          <img className="wwr-card-img wwr-parallax-img" src={recipe.image} alt={recipe.title} />
          <div className="wwr-card-overlay"></div>
          <div className="wwr-card-top">
            <CuisineBadge flag={recipe.cuisine.flag} name={recipe.cuisine.name} size="sm" />
          </div>
          <div className="wwr-card-body wwr-card-body--secondary">
            <div className="wwr-meta">
              <span>{recipe.time}</span>
              <span aria-hidden="true">·</span>
              <span>{recipe.difficulty}</span>
            </div>
            <h2 className="wwr-card-title wwr-card-title--secondary">
              {recipe.title}
            </h2>
            <span className="wwr-cta wwr-cta--sm">
              Ver receta
              <svg className="wwr-cta-arrow" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M4 10h12M11 5l5 5-5 5"/>
              </svg>
            </span>
          </div>
        </div>
      </a>
    </article>
  );
}

/* ---------- Trending bar ---------- */
function TrendingBar({ pills }) {
  // duplicate list for seamless marquee loop
  const loop = [...pills, ...pills];
  return (
    <div className="wwr-trending">
      <div className="wwr-trending-label">
        <span className="wwr-trending-globe" aria-hidden="true">🌍</span>
        <span>Tendencias hoy en worldwiderecipes</span>
        <span className="wwr-trending-dot" aria-hidden="true"></span>
        <span className="wwr-trending-live">EN VIVO</span>
      </div>
      <div className="wwr-trending-track-mask">
        <div className="wwr-trending-track">
          {loop.map((p, i) => (
            <a key={i} href={`#/cocina/${p.label}`} className="wwr-trend-pill">
              <span className="wwr-tp-flag" aria-hidden="true">{p.flag}</span>
              <span className="wwr-tp-label">{p.label}</span>
              <span className="wwr-tp-count">{p.count}</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------- Top bar (light context) ---------- */
function TopBar() {
  const today = new Date().toLocaleDateString("es-ES", {
    weekday: "long", day: "numeric", month: "long", year: "numeric"
  });
  return (
    <header className="wwr-topbar">
      <div className="wwr-topbar-left">
        <span className="wwr-date">{today}</span>
        <span className="wwr-divider" aria-hidden="true">·</span>
        <span className="wwr-edition">Edición España &amp; LATAM</span>
      </div>
      <a className="wwr-logo" href="#/">
        <span className="wwr-logo-mark">worldwiderecipes</span>
        <span className="wwr-logo-dot">.app</span>
      </a>
      <nav className="wwr-nav">
        <a href="#/explorar">Explorar</a>
        <a href="#/colecciones">Colecciones</a>
        <a href="#/tiktok">TikTok</a>
        <a href="#/entrar" className="wwr-nav-cta">Entrar</a>
      </nav>
    </header>
  );
}

/* ---------- Page header (kicker + section title) ---------- */
function SectionKicker() {
  return (
    <div className="wwr-section-head">
      <div className="wwr-section-eyebrow">
        <span className="wwr-eyebrow-line" aria-hidden="true"></span>
        <span>No. 047 · Domingo</span>
      </div>
      <div className="wwr-section-titles">
        <h2 className="wwr-section-title">
          Lo que se cocina <em>hoy.</em>
        </h2>
        <p className="wwr-section-sub">
          Tres recetas elegidas a mano por nuestro equipo en Madrid y Ciudad de México. Cambian cada mañana al servir el café.
        </p>
      </div>
    </div>
  );
}

/* ---------- Main hero ---------- */
function Hero() {
  return (
    <div className="wwr-page">
      <TopBar />
      <main className="wwr-hero">
        <SectionKicker />

        <div className="wwr-hero-grid">
          <FeaturedCard recipe={HERO_RECIPES.featured} />
          <div className="wwr-hero-stack">
            {HERO_RECIPES.secondary.map((r) => (
              <SecondaryCard key={r.id} recipe={r} />
            ))}
          </div>
        </div>

        <TrendingBar pills={TRENDING_PILLS} />
      </main>
    </div>
  );
}

/* Mount */
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<Hero />);

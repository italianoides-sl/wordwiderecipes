/* worldwiderecipes.app — Recipe Page Sections
   Hero, Breadcrumb, Title, Meta, Intro, Ingredients, Steps, Tools, FAQ, Related */

const { useState, useRef, useEffect } = React;

/* ========================================================
   Breadcrumb
   ======================================================== */
function Breadcrumb({ items }) {
  return (
    <nav className="rp-breadcrumb" aria-label="Migas de pan">
      <ol>
        {items.map((it, i) => {
          const last = i === items.length - 1;
          return (
            <li key={i}>
              {it.href && !last ? (
                <a href={it.href}>{it.label}</a>
              ) : (
                <span aria-current={last ? "page" : undefined}>{it.label}</span>
              )}
              {!last && <span className="rp-bc-sep" aria-hidden="true">›</span>}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

/* ========================================================
   Hero image (16:9, full-bleed of left column)
   ======================================================== */
function RecipeHero({ hero, cuisine }) {
  return (
    <figure className="rp-hero">
      <div className="rp-hero-frame">
        <img
          src={hero.src}
          alt=""
          onError={(e) => { e.currentTarget.style.display = "none"; }}
        />
        <div className="rp-hero-fallback" aria-hidden="true"></div>
        <div className="rp-hero-cuisine">
          <span className="rp-hc-flag">{cuisine.flag}</span>
          <span>{cuisine.name}</span>
        </div>
      </div>
      <figcaption className="rp-hero-caption">{hero.credit}</figcaption>
    </figure>
  );
}

/* ========================================================
   Title block
   ======================================================== */
function TitleBlock({ title, subtitle, difficulty }) {
  return (
    <header className="rp-title-block">
      <div className="rp-badges">
        <span className="rp-badge rp-badge-cuisine">Cocina mexicana</span>
        <span className={`rp-badge rp-badge-diff rp-diff-${difficulty.toLowerCase()}`}>
          ● Dificultad {difficulty.toLowerCase()}
        </span>
        <span className="rp-badge rp-badge-diet">Sin gluten</span>
      </div>
      <h1 className="rp-title">{title}</h1>
      <p className="rp-subtitle">{subtitle}</p>
    </header>
  );
}

/* ========================================================
   Meta row
   ======================================================== */
function MetaRow({ items }) {
  return (
    <ul className="rp-meta-row" role="list">
      {items.map((m, i) => (
        <li key={i}>
          <span className="rp-meta-icon" aria-hidden="true">{m.icon}</span>
          <span className="rp-meta-label">{m.label}</span>
        </li>
      ))}
    </ul>
  );
}

/* ========================================================
   Intro paragraph(s)
   ======================================================== */
function Intro({ paragraphs }) {
  return (
    <div className="rp-intro">
      {paragraphs.map((p, i) => (
        <p key={i} className={i === 0 ? "rp-intro-lede" : ""}>{p}</p>
      ))}
    </div>
  );
}

/* ========================================================
   Section header
   ======================================================== */
function SectionHead({ kicker, title, id }) {
  return (
    <header className="rp-section-head" id={id}>
      <div className="rp-section-rule" aria-hidden="true"></div>
      <div className="rp-section-titles">
        <span className="rp-section-kicker">{kicker}</span>
        <h2 className="rp-section-title">{title}</h2>
      </div>
      <div className="rp-section-rule" aria-hidden="true"></div>
    </header>
  );
}

/* ========================================================
   Ingredients
   ======================================================== */
function IngredientList({ groups }) {
  return (
    <section className="rp-ingredients" aria-labelledby="sec-ingredientes">
      <SectionHead kicker="01" title="Ingredientes" id="sec-ingredientes" />

      <div className="rp-ing-servings">
        <span className="rp-ing-servings-label">Cantidades para</span>
        <div className="rp-ing-stepper">
          <button aria-label="Reducir comensales">−</button>
          <span>4 personas</span>
          <button aria-label="Aumentar comensales">+</button>
        </div>
        <span className="rp-ing-system">Sistema métrico</span>
      </div>

      <div className="rp-ing-groups">
        {groups.map((g, gi) => (
          <div className="rp-ing-group" key={gi}>
            <h3 className="rp-ing-group-title">{g.group}</h3>
            <ul className="rp-ing-list">
              {g.items.map((it, ii) => (
                <li key={ii} className={`rp-ing-item ${it.affiliate ? "is-affiliate" : ""}`}>
                  <label className="rp-ing-check">
                    <input type="checkbox" />
                    <span className="rp-ing-box" aria-hidden="true"></span>
                  </label>
                  <span className="rp-ing-qty">{it.qty}</span>
                  {it.affiliate ? (
                    <a className="rp-ing-name rp-ing-link" href={`#/amazon/${encodeURIComponent(it.name)}`}>
                      <span className="rp-ing-text">{it.name}</span>
                      <span className="rp-ing-affiliate-hint">
                        <svg viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                          <circle cx="6.5" cy="15.5" r="1.2"/>
                          <circle cx="13" cy="15.5" r="1.2"/>
                          <path d="M1 2h2l2 9h10l2-6H5"/>
                        </svg>
                        Comprar en {it.store}
                        <span className="rp-ing-arrow">→</span>
                      </span>
                    </a>
                  ) : (
                    <span className="rp-ing-name">{it.name}</span>
                  )}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ========================================================
   Inline ad placeholder (AdSense)
   ======================================================== */
function InlineAd({ label = "Anuncio · Patrocinado" }) {
  return (
    <aside className="rp-ad" aria-label={label}>
      <div className="rp-ad-frame">
        <span className="rp-ad-lbl">{label}</span>
        <div className="rp-ad-body">
          <div className="rp-ad-thumb" aria-hidden="true"></div>
          <div className="rp-ad-copy">
            <span className="rp-ad-brand">Maseca · Harina de maíz</span>
            <p className="rp-ad-title">La tradición que nunca falla en tu cocina.</p>
            <span className="rp-ad-cta">Conoce más →</span>
          </div>
        </div>
        <span className="rp-ad-meta">Google Ads · ID 7280-A</span>
      </div>
    </aside>
  );
}

/* ========================================================
   Steps
   ======================================================== */
function StepList({ steps }) {
  return (
    <section className="rp-steps" aria-labelledby="sec-pasos">
      <SectionHead kicker="02" title="Paso a paso" id="sec-pasos" />

      <ol className="rp-step-list">
        {steps.map((s, i) => (
          <React.Fragment key={s.n}>
            <li className="rp-step">
              <div className="rp-step-num" aria-hidden="true">
                <span className="rp-step-num-label">Paso</span>
                <span className="rp-step-num-value">{String(s.n).padStart(2, "0")}</span>
              </div>
              <div className="rp-step-body">
                <p>{s.body}</p>
                <div className="rp-step-actions">
                  <button className="rp-step-action" aria-label="Marcar paso completado">
                    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <circle cx="8" cy="8" r="6.5"/>
                      <path d="M5 8l2 2 4-4"/>
                    </svg>
                    Hecho
                  </button>
                  <button className="rp-step-action" aria-label="Iniciar temporizador">
                    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <circle cx="8" cy="9" r="5.5"/>
                      <path d="M8 9V6M6 1.5h4"/>
                    </svg>
                    Temporizador
                  </button>
                </div>
              </div>
            </li>
            {/* Inline ad every 3rd step */}
            {(s.n % 3 === 0 && s.n < steps.length) && <InlineAd />}
          </React.Fragment>
        ))}
      </ol>
    </section>
  );
}

/* ========================================================
   Tools — Herramientas recomendadas
   ======================================================== */
function ToolThumb({ from, to, shape }) {
  return (
    <div className="rp-tool-thumb" style={{ background: `linear-gradient(135deg, ${from} 0%, ${to} 100%)` }}>
      <svg className="rp-tool-icon" viewBox="0 0 100 100" fill="none" aria-hidden="true">
        {shape === "pot" && (
          <g stroke="rgba(255,255,255,0.85)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M22 40h56v34a8 8 0 0 1-8 8H30a8 8 0 0 1-8-8V40z"/>
            <path d="M18 40h64M30 30v10M70 30v10"/>
            <path d="M40 18c0 6 4 6 4 12M52 18c0 6 4 6 4 12"/>
          </g>
        )}
        {shape === "molcajete" && (
          <g stroke="rgba(255,255,255,0.85)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <ellipse cx="50" cy="58" rx="32" ry="14"/>
            <path d="M18 58c0 14 14 22 32 22s32-8 32-22"/>
            <ellipse cx="50" cy="58" rx="20" ry="8"/>
            <circle cx="35" cy="30" r="3"/>
            <circle cx="65" cy="32" r="2.5"/>
            <circle cx="55" cy="24" r="2"/>
          </g>
        )}
        {shape === "knife" && (
          <g stroke="rgba(28,20,16,0.7)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M10 60l50-40 8 6L20 70z" fill="rgba(255,255,255,0.7)"/>
            <rect x="62" y="22" width="22" height="10" rx="2" fill="rgba(28,20,16,0.85)"/>
            <path d="M66 25h14M66 29h14" stroke="rgba(255,255,255,0.4)" strokeWidth="0.8"/>
          </g>
        )}
      </svg>
    </div>
  );
}

function ToolsGrid({ tools }) {
  return (
    <section className="rp-tools" aria-labelledby="sec-herramientas">
      <SectionHead kicker="03" title="Herramientas recomendadas" id="sec-herramientas" />
      <p className="rp-tools-intro">
        Lo que usamos en nuestra cocina para esta receta. Si compras a través de estos enlaces, recibimos una pequeña comisión sin costo extra para ti.
      </p>
      <div className="rp-tools-grid">
        {tools.map((t, i) => (
          <article className="rp-tool-card" key={i}>
            <a href={t.url} className="rp-tool-link">
              <ToolThumb {...t.img} />
              <div className="rp-tool-body">
                <span className="rp-tool-brand">{t.brand}</span>
                <h3 className="rp-tool-name">{t.name}</h3>
                <div className="rp-tool-stars">
                  <span className="rp-stars" aria-label={`${t.stars} de 5`}>
                    {"★★★★★"} <span className="rp-stars-empty">{"★★★★★"}</span>
                    <span className="rp-stars-fill" style={{ width: `${(t.stars/5)*100}%` }}>★★★★★</span>
                  </span>
                  <span className="rp-tool-reviews">{t.reviews.toLocaleString("es-MX")} reseñas</span>
                </div>
                <div className="rp-tool-footer">
                  <span className="rp-tool-price">{t.price}</span>
                  <span className="rp-tool-cta">
                    Ver en Amazon
                    <svg viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d="M3 9h12M10 4l5 5-5 5"/>
                    </svg>
                  </span>
                </div>
              </div>
            </a>
          </article>
        ))}
      </div>
    </section>
  );
}

/* ========================================================
   FAQ — Accordion
   ======================================================== */
function FAQ({ faqs }) {
  const [open, setOpen] = useState(0);
  return (
    <section className="rp-faq" aria-labelledby="sec-faq">
      <SectionHead kicker="04" title="Preguntas frecuentes" id="sec-faq" />
      <ul className="rp-faq-list" role="list">
        {faqs.map((f, i) => {
          const isOpen = open === i;
          return (
            <li key={i} className={`rp-faq-item ${isOpen ? "is-open" : ""}`}>
              <button
                className="rp-faq-q"
                onClick={() => setOpen(isOpen ? -1 : i)}
                aria-expanded={isOpen}
              >
                <span className="rp-faq-q-num">{String(i + 1).padStart(2, "0")}</span>
                <span className="rp-faq-q-text">{f.q}</span>
                <span className="rp-faq-q-icon" aria-hidden="true">
                  <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                    <path d="M3 6l5 5 5-5"/>
                  </svg>
                </span>
              </button>
              <div className="rp-faq-a" role="region">
                <p>{f.a}</p>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

/* ========================================================
   Related content
   ======================================================== */
function Related({ items }) {
  return (
    <section className="rp-related" aria-labelledby="sec-related">
      <header className="rp-related-head">
        <span className="rp-section-kicker">05</span>
        <h2 className="rp-related-title">También te puede interesar</h2>
      </header>
      <div className="rp-related-grid">
        {items.map((it, i) => (
          <a key={i} href={`#/relacionado/${i}`} className="rp-related-card">
            <div
              className="rp-related-img"
              style={{ background: `linear-gradient(135deg, ${it.img.from} 0%, ${it.img.to} 100%)` }}
              aria-hidden="true"
            ></div>
            <div className="rp-related-body">
              <span className="rp-related-kind">{it.kind}</span>
              <h3 className="rp-related-h">{it.title}</h3>
              <span className="rp-related-meta">{it.time} de lectura</span>
            </div>
          </a>
        ))}
      </div>
    </section>
  );
}

/* Export to window so the page composer can use them */
Object.assign(window, {
  Breadcrumb, RecipeHero, TitleBlock, MetaRow, Intro,
  IngredientList, StepList, ToolsGrid, FAQ, Related,
});

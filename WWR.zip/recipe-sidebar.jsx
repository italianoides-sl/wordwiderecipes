/* worldwiderecipes.app — Recipe Page Sidebar
   JumpNav, TikTokCTA, AffiliateOfWeek, Newsletter */

const { useState: useStateSB, useEffect: useEffectSB } = React;

/* ========================================================
   Jump-to navigation with scroll-spy
   ======================================================== */
function JumpNav() {
  const links = [
    { id: "sec-ingredientes", label: "Ingredientes" },
    { id: "sec-pasos",        label: "Paso a paso" },
    { id: "sec-herramientas", label: "Herramientas" },
    { id: "sec-faq",          label: "Preguntas" },
  ];
  const [active, setActive] = useStateSB("sec-ingredientes");

  useEffectSB(() => {
    const els = links.map((l) => document.getElementById(l.id)).filter(Boolean);
    if (!els.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        // pick the topmost intersecting
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]) setActive(visible[0].target.id);
      },
      { rootMargin: "-20% 0px -60% 0px", threshold: 0 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <nav className="sb-jump" aria-label="Saltar a sección">
      <span className="sb-kicker">En esta receta</span>
      <ol>
        {links.map((l, i) => {
          const isActive = active === l.id;
          return (
            <li key={l.id} className={isActive ? "is-active" : ""}>
              <a href={`#${l.id}`} onClick={(e) => {
                e.preventDefault();
                const el = document.getElementById(l.id);
                if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 80, behavior: "smooth" });
              }}>
                <span className="sb-jump-num">{String(i + 1).padStart(2, "0")}</span>
                <span className="sb-jump-label">{l.label}</span>
                <span className="sb-jump-bar" aria-hidden="true"></span>
              </a>
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

/* ========================================================
   TikTok CTA block (dark, branded)
   ======================================================== */
function TikTokCTA({ data }) {
  return (
    <a className="sb-tiktok" href={data.url} target="_blank" rel="noopener">
      <div className="sb-tt-spine" aria-hidden="true"></div>
      <div className="sb-tt-eyebrow">
        <span className="sb-tt-pulse" aria-hidden="true"></span>
        FOTO-RECETAS · {data.handle}
      </div>
      <h3 className="sb-tt-title">{data.title}</h3>
      <p className="sb-tt-sub">{data.sub}</p>
      <div className="sb-tt-footer">
        <span className="sb-tt-btn">
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43V8.55a8.16 8.16 0 0 0 4.77 1.52V6.69h-1.84z"/>
          </svg>
          Ver en TikTok
        </span>
        <span className="sb-tt-views">{data.followers || "+30K seguidores"}</span>
      </div>
      <div className="sb-tt-phones" aria-hidden="true">
        <span className="sb-tt-phone sb-tt-phone-1"></span>
        <span className="sb-tt-phone sb-tt-phone-2"></span>
      </div>
    </a>
  );
}

/* ========================================================
   Affiliate product of the week
   ======================================================== */
function AffiliateOfWeek({ data }) {
  return (
    <a className="sb-affil" href={data.url} target="_blank" rel="noopener">
      <header className="sb-affil-head">
        <span className="sb-affil-kicker">Producto de la semana</span>
        <span className="sb-affil-badge">{data.badge}</span>
      </header>
      <div className="sb-affil-body">
        <div
          className="sb-affil-img"
          style={{ background: `linear-gradient(135deg, ${data.img.from} 0%, ${data.img.to} 100%)` }}
          aria-hidden="true"
        >
          <svg viewBox="0 0 100 100" fill="none" aria-hidden="true">
            <g stroke="rgba(255,255,255,0.9)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 42h56v34a8 8 0 0 1-8 8H30a8 8 0 0 1-8-8V42z"/>
              <path d="M18 42h64M30 32v10M70 32v10"/>
              <circle cx="50" cy="28" r="2.5" fill="rgba(255,255,255,0.9)"/>
              <path d="M40 48v4M50 48v4M60 48v4"/>
            </g>
          </svg>
        </div>
        <div className="sb-affil-info">
          <h4>{data.title}</h4>
          <p>{data.subtitle}</p>
          <div className="sb-affil-stars">
            <span className="rp-stars" aria-label={`${data.stars} de 5`}>
              <span className="rp-stars-empty">★★★★★</span>
              <span className="rp-stars-fill" style={{ width: `${(data.stars/5)*100}%` }}>★★★★★</span>
            </span>
            <span>{data.reviews.toLocaleString("es-MX")} reseñas</span>
          </div>
          <div className="sb-affil-price">
            <span className="sb-affil-price-now">{data.price}</span>
            <span className="sb-affil-price-was">{data.priceWas}</span>
          </div>
        </div>
      </div>
      <span className="sb-affil-cta">
        Ver en Amazon
        <svg viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M3 9h12M10 4l5 5-5 5"/>
        </svg>
      </span>
    </a>
  );
}

/* ========================================================
   Newsletter (Brevo style, minimal)
   ======================================================== */
function Newsletter() {
  const [email, setEmail] = useStateSB("");
  const [state, setState] = useStateSB("idle"); // idle | loading | success

  function onSubmit(e) {
    e.preventDefault();
    if (!email.includes("@")) return;
    setState("loading");
    setTimeout(() => setState("success"), 600);
  }

  return (
    <div className="sb-newsletter">
      <div className="sb-nl-mark" aria-hidden="true">
        <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
          <rect x="4" y="8" width="24" height="18" rx="1"/>
          <path d="M4 9l12 9 12-9"/>
        </svg>
      </div>
      <span className="sb-kicker">Boletín dominical</span>
      <h3 className="sb-nl-title">Una receta nueva cada domingo.</h3>
      <p className="sb-nl-sub">
        Sin spam. Sin algoritmos. Solo una historia y una receta de algún rincón del mundo, en tu correo.
      </p>
      {state === "success" ? (
        <div className="sb-nl-success" role="status">
          ✓ Listo. Revisa tu correo para confirmar.
        </div>
      ) : (
        <form className="sb-nl-form" onSubmit={onSubmit}>
          <input
            type="email"
            placeholder="tu@correo.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            aria-label="Correo electrónico"
            required
          />
          <button type="submit" disabled={state === "loading"}>
            {state === "loading" ? "Enviando…" : "Suscribir"}
          </button>
        </form>
      )}
      <span className="sb-nl-meta">14.382 cocineros suscritos · Brevo</span>
    </div>
  );
}

/* Export */
Object.assign(window, { JumpNav, TikTokCTA, AffiliateOfWeek, Newsletter });

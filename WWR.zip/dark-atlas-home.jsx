/* worldwiderecipes.app — Dark Atlas · Homepage
   Sections: Hero · About · What we do · Stats · Explore CTA · TikTok band · Footer */

const { useState: useStateH, useEffect: useEffectH, useRef: useRefH } = React;

/* ============================================================
   Animated star particles — CSS only via many box-shadow dots
   Generated once at module load.
   ============================================================ */
const STARS_SMALL = (() => {
  const dots = [];
  for (let i = 0; i < 140; i++) {
    const x = Math.floor(Math.random() * 1800);
    const y = Math.floor(Math.random() * 900);
    const a = (Math.random() * 0.5 + 0.15).toFixed(2);
    dots.push(`${x}px ${y}px rgba(240, 236, 228, ${a})`);
  }
  return dots.join(", ");
})();
const STARS_BIG = (() => {
  const dots = [];
  for (let i = 0; i < 22; i++) {
    const x = Math.floor(Math.random() * 1800);
    const y = Math.floor(Math.random() * 900);
    const a = (Math.random() * 0.35 + 0.25).toFixed(2);
    dots.push(`${x}px ${y}px rgba(232, 197, 106, ${a})`);
  }
  return dots.join(", ");
})();

/* ============================================================
   HERO
   ============================================================ */
function HeroSection({ onExplore }) {
  return (
    <section className="da-hero">
      {/* star particles */}
      <div className="da-stars da-stars--small" style={{ boxShadow: STARS_SMALL }}></div>
      <div className="da-stars da-stars--big" style={{ boxShadow: STARS_BIG }}></div>
      {/* amber glow top-right */}
      <div className="da-hero-glow" aria-hidden="true"></div>
      {/* vignette */}
      <div className="da-hero-vignette" aria-hidden="true"></div>

      <div className="da-hero-inner">
        <div className="da-overline da-fade" style={{ "--i": 0 }}>
          <span className="da-overline-dot"></span>
          LA COCINA DEL MUNDO · IA GENERATIVA · 5 IDIOMAS
        </div>

        <h1 className="da-hero-h1">
          <span className="da-fade" style={{ "--i": 1 }}>La cocina del</span>{" "}
          <span className="da-fade da-h1-accent" style={{ "--i": 2 }}>mundo entero,</span>{" "}
          <span className="da-fade" style={{ "--i": 3 }}>en un solo lugar.</span>
        </h1>

        <p className="da-hero-sub da-fade" style={{ "--i": 4 }}>
          Miles de recetas, técnicas, ingredientes y guías de cocina — generadas por IA,
          revisadas por chefs, publicadas cada día en cinco idiomas.
        </p>

        <div className="da-hero-ctas da-fade" style={{ "--i": 5 }}>
          <button className="da-btn da-btn--primary" onClick={onExplore}>
            <span className="da-btn-icon">🌐</span>
            <span>Explorar el mapa mundial</span>
            <svg className="da-btn-arrow" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 10h12M11 5l5 5-5 5"/>
            </svg>
          </button>
          <a className="da-btn da-btn--ghost" href="https://www.tiktok.com/@tuvirtualchef" target="_blank" rel="noopener">
            <span className="da-btn-icon">📺</span>
            <span>@tuvirtualchef en TikTok</span>
          </a>
        </div>
      </div>

      <div className="da-hero-stats da-fade" style={{ "--i": 6 }}>
        <div><span className="da-hs-num">1.300+</span><span className="da-hs-lbl">páginas</span></div>
        <span className="da-hs-sep">|</span>
        <div><span className="da-hs-num">5</span><span className="da-hs-lbl">idiomas</span></div>
        <span className="da-hs-sep">|</span>
        <div><span className="da-hs-num">20+</span><span className="da-hs-lbl">países</span></div>
      </div>

      {/* scroll cue */}
      <div className="da-scroll-cue" aria-hidden="true">
        <span>desliza</span>
        <span className="da-scroll-line"></span>
      </div>
    </section>
  );
}

/* ============================================================
   ABOUT — Quiénes Somos (warm cream)
   ============================================================ */
const ABOUT_PHOTOS = [
  "https://images.unsplash.com/photo-1547592180-85f173990554?w=1200&q=80&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1476224203421-9ac39bcb3327?w=600&q=80&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=600&q=80&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1496116218417-1a781b1c416c?w=600&q=80&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=600&q=80&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600&q=80&auto=format&fit=crop",
];

const ABOUT_TAGS = [
  { name: "España", flag: "🇪🇸" },
  { name: "México", flag: "🇲🇽" },
  { name: "Japón", flag: "🇯🇵" },
  { name: "India", flag: "🇮🇳" },
  { name: "Perú", flag: "🇵🇪" },
  { name: "Italia", flag: "🇮🇹" },
];

function AboutSection() {
  return (
    <section className="da-about">
      <div className="da-about-grid">
        <div className="da-about-copy">
          <div className="da-overline da-overline--terracotta">QUIÉNES SOMOS</div>
          <h2 className="da-about-h2">
            Un chef, una cámara,
            <br />
            <em>y el mundo entero</em>
            <br />
            para cocinar.
          </h2>
          <p>
            Nacimos en Ibiza, en la cocina de un chef que cambió los fogones por la
            cámara y se hizo un hueco en TikTok como <strong>@tuvirtualchef</strong>.
            La idea era simple: enseñar a cocinar en menos de un minuto.
          </p>
          <p>
            <strong>worldwiderecipes.app</strong> es la otra mitad del proyecto.
            Un atlas digital de recetas, técnicas, ingredientes y guías — generadas
            con IA y revisadas por chefs — publicado cada día en cinco idiomas.
          </p>
          <p>
            Porque la gastronomía es patrimonio global. Y porque nadie tiene tiempo
            de leer un libro de cocina cuando solo quiere saber cómo se hace el sofrito.
          </p>
          <div className="da-tags">
            {ABOUT_TAGS.map((t) => (
              <span key={t.name} className="da-tag">
                <span className="da-tag-flag">{t.flag}</span>
                {t.name}
              </span>
            ))}
            <span className="da-tag da-tag--ghost">+ 15 más</span>
          </div>
        </div>

        <div className="da-about-mosaic">
          <a className="da-photo da-photo--hero" href="#" onClick={(e) => e.preventDefault()}>
            <img src={ABOUT_PHOTOS[0]} alt="" loading="lazy"/>
          </a>
          {ABOUT_PHOTOS.slice(1).map((src, i) => (
            <a key={i} className="da-photo" href="#" onClick={(e) => e.preventDefault()}>
              <img src={src} alt="" loading="lazy"/>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   QUÉ HACEMOS — type cards
   ============================================================ */
const TYPE_CARDS = [
  { icon: "🍳", title: "Recetas",     copy: "De entrante a postre, de 20 min a 24 horas.",   count: "500+", color: "#E07B5A" },
  { icon: "🔪", title: "Técnicas",    copy: "Brunoise, fermentación, sous vide y mucho más.", count: "200+", color: "#6BBFBA" },
  { icon: "🌿", title: "Ingredientes", copy: "Origen, sabor, sustitutos y dónde comprarlos.",  count: "300+", color: "#7DC87D" },
  { icon: "📖", title: "Guías",       copy: "Rutas gastronómicas por país y región.",         count: "150+", color: "#B890D8" },
  { icon: "🌶️", title: "Especias",   copy: "Historia, Scoville, maridajes y recetas.",       count: "120+", color: "#E8C56A" },
  { icon: "🗺️", title: "Cocinas",    copy: "Historia y platos icónicos de cada país.",       count: "80+",  color: "#E8C56A" },
];

function WhatWeDoSection() {
  return (
    <section className="da-what">
      <div className="da-section-head">
        <div className="da-overline">QUÉ ENCONTRARÁS</div>
        <h2 className="da-section-h2">
          Seis maneras de <em>cocinar mejor.</em>
        </h2>
      </div>
      <div className="da-type-grid">
        {TYPE_CARDS.map((c) => (
          <article key={c.title} className="da-type-card" style={{ "--c": c.color }}>
            <div className="da-type-head">
              <span className="da-type-icon">{c.icon}</span>
              <span className="da-type-count" style={{ color: c.color }}>{c.count}</span>
            </div>
            <h3 className="da-type-title">{c.title}</h3>
            <p className="da-type-copy">{c.copy}</p>
            <div className="da-type-bar"><span></span></div>
          </article>
        ))}
      </div>
    </section>
  );
}

/* ============================================================
   STATS bar (cream)
   ============================================================ */
function StatsSection() {
  return (
    <section className="da-statbar">
      <div className="da-statbar-grid">
        <div className="da-stat">
          <span className="da-stat-num">1.300<span className="da-stat-plus">+</span></span>
          <span className="da-stat-lbl">páginas publicadas</span>
        </div>
        <div className="da-stat">
          <span className="da-stat-num">10</span>
          <span className="da-stat-lbl">categorías editoriales</span>
        </div>
        <div className="da-stat">
          <span className="da-stat-num">5</span>
          <span className="da-stat-lbl">idiomas en directo</span>
        </div>
        <div className="da-stat">
          <span className="da-stat-num">20<span className="da-stat-plus">+</span></span>
          <span className="da-stat-lbl">países con contenido</span>
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   Explore CTA — teal glow band
   ============================================================ */
function ExploreCTASection({ onExplore }) {
  return (
    <section className="da-explore-cta">
      <div className="da-cta-glow da-cta-glow-1"></div>
      <div className="da-cta-glow da-cta-glow-2"></div>
      <div className="da-cta-inner">
        <div className="da-overline da-overline--jade">EXPLORAR</div>
        <h2 className="da-cta-h2">
          Empieza por el <em>mapa.</em>
        </h2>
        <p className="da-cta-sub">
          Haz click en cualquier país para ver qué recetas, técnicas e ingredientes hemos publicado.
        </p>
        <button className="da-btn da-btn--primary" onClick={onExplore}>
          <span className="da-btn-icon">🌐</span>
          <span>Abrir el mapa interactivo</span>
          <svg className="da-btn-arrow" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 10h12M11 5l5 5-5 5"/>
          </svg>
        </button>
      </div>
    </section>
  );
}

/* ============================================================
   TikTok band
   ============================================================ */
function TikTokBand() {
  const tags = ["#cocinaen60s", "#técnicasdecocina", "#recetasrápidas", "#tuvirtualchef"];
  return (
    <section className="da-tt">
      <div className="da-tt-glow"></div>
      <div className="da-tt-grid">
        <div className="da-tt-copy">
          <div className="da-overline da-overline--tt">VÍA TIKTOK</div>
          <h2 className="da-tt-h2">
            ¿Prefieres verlo <em>en vídeo?</em>
          </h2>
          <p className="da-tt-sub">
            Foto-recetas y técnicas en TikTok — desliza, lee, cocina. Una nueva cada semana.
          </p>
        </div>
        <div className="da-tt-tags">
          {tags.map((t) => (
            <a key={t} className="da-tt-tag" href={`https://www.tiktok.com/tag/${t.replace("#", "")}`} target="_blank" rel="noopener">{t}</a>
          ))}
        </div>
        <div className="da-tt-cta-wrap">
          <a className="da-btn da-btn--tt" href="https://www.tiktok.com/@tuvirtualchef" target="_blank" rel="noopener">
            <span className="da-btn-tri">▶</span>
            <span>Ver @tuvirtualchef</span>
          </a>
          <span className="da-tt-followers">+30K seguidores</span>
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   Footer
   ============================================================ */
function Footer() {
  return (
    <footer className="da-footer">
      <div className="da-footer-grid">
        <div>© {new Date().getFullYear()} worldwiderecipes.app — Ibiza & el mundo</div>
        <div className="da-footer-links">
          <a href="#" onClick={(e) => e.preventDefault()}>Sobre</a>
          <a href="#" onClick={(e) => e.preventDefault()}>Idioma · ES</a>
          <a href="#" onClick={(e) => e.preventDefault()}>Privacidad</a>
          <a href="https://www.tiktok.com/@tuvirtualchef" target="_blank" rel="noopener">@tuvirtualchef ↗</a>
        </div>
      </div>
    </footer>
  );
}

/* ============================================================
   HomePage — composes all sections
   ============================================================ */
function HomePage({ onExplore }) {
  return (
    <main className="da-home">
      <HeroSection onExplore={onExplore} />
      <AboutSection />
      <WhatWeDoSection />
      <StatsSection />
      <ExploreCTASection onExplore={onExplore} />
      <TikTokBand />
      <Footer />
    </main>
  );
}

Object.assign(window, { HomePage });

/* worldwiderecipes.app — Homepage supporting sections
   A) Cuisine Grid · B) Técnica del Día · C) Ingrediente Destacado */

const { useEffect, useRef, useState } = React;

/* ============================================================
   useInViewSec — local scroll-in hook (independent of others)
   ============================================================ */
function useInViewSec({ threshold = 0.15, once = true } = {}) {
  const ref = useRef(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { setInView(true); return; }
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting) { setInView(true); if (once) io.unobserve(el); }
        else if (!once) setInView(false);
      }),
      { threshold }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold, once]);
  return [ref, inView];
}

/* ============================================================
   Data
   ============================================================ */
const COUNTRIES = [
  { code: "mx", flag: "🇲🇽", name: "México",     recipes: 412 },
  { code: "es", flag: "🇪🇸", name: "España",     recipes: 387 },
  { code: "it", flag: "🇮🇹", name: "Italia",     recipes: 245 },
  { code: "jp", flag: "🇯🇵", name: "Japón",      recipes: 198 },
  { code: "fr", flag: "🇫🇷", name: "Francia",    recipes: 178 },
  { code: "in", flag: "🇮🇳", name: "India",      recipes: 156 },
  { code: "th", flag: "🇹🇭", name: "Tailandia",  recipes: 134 },
  { code: "pe", flag: "🇵🇪", name: "Perú",       recipes:  92 },
  { code: "gr", flag: "🇬🇷", name: "Grecia",     recipes:  84 },
  { code: "ma", flag: "🇲🇦", name: "Marruecos",  recipes:  67 },
];

const TECHNIQUE = {
  kicker: "Técnica del día · Domingo",
  title: "El sofrito perfecto: la base de toda buena cocina",
  subtitle: "Cebolla, ajo, tomate y aceite — el cuarteto fundacional. La diferencia entre un guiso correcto y uno memorable está en los veinte minutos que le dediques.",
  description: "Aprende a controlar el calor, a leer el color del aceite y a saber exactamente cuándo añadir cada ingrediente. Una técnica que viaja del Mediterráneo a México y se reinventa en cada cocina.",
  difficulty: "Intermedia",
  duration: "15 min de lectura",
  videos: 4,
};

const INGREDIENT = {
  name: "AZAFRÁN",
  nameDisplay: "Azafrán",
  kicker: "Ingrediente del mes · Octubre",
  origin: "La Mancha, España · Khorasan, Irán",
  description: "Tres estigmas por flor, 150.000 flores por kilo. El azafrán es el ingrediente más caro del mundo por gramo, y la espina dorsal de los grandes arroces, los biryanis y la bullabesa. Su recolección sigue siendo manual, al amanecer, durante apenas tres semanas al año.",
  flavors: ["Floral", "Terroso", "Cálido", "Miel amarga", "Yodado"],
  scoville: null,
  origin_country: "es",
  origin_flag: "🇪🇸",
  recipes_count: 47,
  pairs_with: ["arroz bomba", "marisco", "cordero", "naranja amarga", "almendra"],
};

/* ============================================================
   Section A — Cuisine Grid
   ============================================================ */
function CuisineGrid() {
  const [ref, inView] = useInViewSec({ threshold: 0.1 });
  return (
    <section ref={ref} className={`hs hs-a ${inView ? "is-visible" : ""}`}>
      <header className="hs-head">
        <div className="hs-kicker">
          <span className="hs-kicker-line"></span>
          Sección 01 · Atlas
          <span className="hs-kicker-num">10 países</span>
        </div>
        <div className="hs-head-row">
          <h2 className="hs-title">
            La cocina del mundo,<br/>
            <em>en un solo lugar.</em>
          </h2>
          <a className="hs-link" href="#/paises">
            Ver todos los países
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3 8h10M9 4l4 4-4 4"/></svg>
          </a>
        </div>
      </header>

      <div className="hs-grid">
        {COUNTRIES.map((c, i) => (
          <a
            key={c.code}
            href={`#/cocina/${c.code}`}
            className="cc"
            style={{ "--i": i }}
          >
            <span className="cc-flag" aria-hidden="true">{c.flag}</span>
            <span className="cc-name">{c.name}</span>
            <span className="cc-count">
              {c.recipes.toLocaleString("es-ES")} <span>recetas</span>
            </span>
            <span className="cc-arrow" aria-hidden="true">→</span>
          </a>
        ))}
      </div>
    </section>
  );
}

/* ============================================================
   Section B — Técnica del Día
   ============================================================ */
function TechniqueOfDay() {
  const [ref, inView] = useInViewSec({ threshold: 0.2 });
  return (
    <section ref={ref} className={`hs hs-b ${inView ? "is-visible" : ""}`}>
      <header className="hs-head">
        <div className="hs-kicker">
          <span className="hs-kicker-line"></span>
          Sección 02 · Aprende
          <span className="hs-kicker-num">Técnica</span>
        </div>
      </header>

      <article className="td-card">
        {/* Image side */}
        <div className="td-img" aria-hidden="true">
          <div className="td-img-bg"></div>
          <div className="td-img-texture"></div>
          {/* Sofrito SVG illustration */}
          <svg className="td-img-svg" viewBox="0 0 400 500" preserveAspectRatio="xMidYMid slice">
            <defs>
              <radialGradient id="td-pan-glow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#E8A838" stopOpacity="0.6"/>
                <stop offset="60%" stopColor="#C4533A" stopOpacity="0.3"/>
                <stop offset="100%" stopColor="#2D3A2E" stopOpacity="0"/>
              </radialGradient>
            </defs>
            {/* Steam wisps */}
            <g stroke="rgba(232, 224, 213, 0.18)" strokeWidth="1.5" fill="none" strokeLinecap="round">
              <path d="M140 200 Q 130 170 145 140 Q 160 110 145 80"/>
              <path d="M200 200 Q 210 170 195 140 Q 180 110 200 80"/>
              <path d="M260 200 Q 250 170 265 140 Q 280 110 265 80"/>
            </g>
            {/* Pan */}
            <g>
              <ellipse cx="200" cy="320" rx="160" ry="36" fill="rgba(0,0,0,0.35)"/>
              <path d="M40 320 L60 380 Q 80 400 130 400 L270 400 Q 320 400 340 380 L360 320 Z" fill="#1C1410"/>
              <ellipse cx="200" cy="320" rx="158" ry="34" fill="#2A1E18"/>
              <ellipse cx="200" cy="316" rx="148" ry="30" fill="url(#td-pan-glow)"/>
              {/* Veg bits */}
              <g fill="#C4533A">
                <circle cx="170" cy="316" r="8"/>
                <circle cx="220" cy="320" r="9"/>
                <circle cx="195" cy="324" r="7"/>
                <circle cx="240" cy="312" r="6"/>
              </g>
              <g fill="#E8A838">
                <circle cx="155" cy="320" r="5"/>
                <circle cx="185" cy="318" r="4"/>
                <circle cx="230" cy="324" r="5"/>
                <circle cx="200" cy="312" r="4"/>
              </g>
              <g fill="#F6E3DC" opacity="0.7">
                <circle cx="175" cy="312" r="3"/>
                <circle cx="210" cy="320" r="3"/>
                <circle cx="225" cy="318" r="2.5"/>
              </g>
              {/* Handle */}
              <rect x="358" y="334" width="38" height="8" rx="3" fill="#1C1410"/>
            </g>
          </svg>
          <span className="td-img-label">Sofrito al fuego medio · 22 min</span>
        </div>

        {/* Content side */}
        <div className="td-body">
          <span className="td-kicker">{TECHNIQUE.kicker}</span>
          <h3 className="td-title">{TECHNIQUE.title}</h3>
          <p className="td-subtitle">{TECHNIQUE.subtitle}</p>
          <p className="td-description">{TECHNIQUE.description}</p>

          <ul className="td-meta">
            <li>
              <span className="td-meta-label">Dificultad</span>
              <span className="td-badge td-badge-diff">● {TECHNIQUE.difficulty}</span>
            </li>
            <li>
              <span className="td-meta-label">Lectura</span>
              <span className="td-meta-value">{TECHNIQUE.duration}</span>
            </li>
            <li>
              <span className="td-meta-label">Vídeos</span>
              <span className="td-meta-value">{TECHNIQUE.videos} pasos en vídeo</span>
            </li>
          </ul>

          <a href="#/tecnica/sofrito-perfecto" className="td-cta">
            Aprender esta técnica
            <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 10h12M11 5l5 5-5 5"/>
            </svg>
          </a>
        </div>
      </article>
    </section>
  );
}

/* ============================================================
   Section C — Ingrediente Destacado
   ============================================================ */
function IngredientFeature() {
  const [ref, inView] = useInViewSec({ threshold: 0.15 });
  return (
    <section ref={ref} className={`hs hs-c ${inView ? "is-visible" : ""}`}>
      <header className="hs-head">
        <div className="hs-kicker">
          <span className="hs-kicker-line"></span>
          Sección 03 · Materia prima
          <span className="hs-kicker-num">Octubre</span>
        </div>
      </header>

      <div className="if-stage">
        {/* Watermark display name */}
        <div className="if-watermark" aria-hidden="true">
          <span className="if-watermark-text">{INGREDIENT.name}</span>
          <span className="if-watermark-mark">Nº 47</span>
        </div>

        {/* Overlapping content card */}
        <div className="if-grid">
          <div className="if-image">
            <div className="if-image-bg"></div>
            <svg className="if-image-svg" viewBox="0 0 300 400" preserveAspectRatio="xMidYMid slice">
              <defs>
                <radialGradient id="if-glow" cx="50%" cy="55%" r="45%">
                  <stop offset="0%" stopColor="#E8A838" stopOpacity="0.5"/>
                  <stop offset="100%" stopColor="#6B4A0E" stopOpacity="0"/>
                </radialGradient>
              </defs>
              <ellipse cx="150" cy="220" rx="130" ry="80" fill="url(#if-glow)"/>
              {/* Saffron threads */}
              <g stroke="#A8412C" strokeWidth="2.5" fill="none" strokeLinecap="round">
                <path d="M50 100 Q 80 150 70 220 Q 65 280 100 320"/>
                <path d="M120 80 Q 100 140 130 220 Q 150 290 130 340"/>
                <path d="M180 90 Q 200 160 170 230 Q 150 300 180 350"/>
                <path d="M240 110 Q 220 170 250 230 Q 270 290 240 340"/>
                <path d="M80 130 Q 110 180 90 240 Q 80 290 110 330"/>
                <path d="M200 100 Q 180 150 210 220 Q 230 280 200 320"/>
              </g>
              <g stroke="#C4533A" strokeWidth="1.5" fill="none" strokeLinecap="round" opacity="0.7">
                <path d="M70 110 Q 90 160 80 220 Q 75 270 100 310"/>
                <path d="M150 80 Q 130 140 160 220 Q 180 290 160 340"/>
                <path d="M220 120 Q 240 170 220 230 Q 200 290 230 330"/>
              </g>
              {/* "Stamen tips" highlights */}
              <g fill="#E8A838">
                <circle cx="50" cy="100" r="3"/>
                <circle cx="120" cy="80" r="3"/>
                <circle cx="180" cy="90" r="3"/>
                <circle cx="240" cy="110" r="3"/>
                <circle cx="150" cy="80" r="2.5"/>
              </g>
            </svg>
            <div className="if-image-tape" aria-hidden="true">Fig. III</div>
          </div>

          <div className="if-content">
            <div className="if-content-top">
              <span className="if-kicker">{INGREDIENT.kicker}</span>
              <span className="if-origin">
                <span className="if-origin-flag" aria-hidden="true">{INGREDIENT.origin_flag}</span>
                {INGREDIENT.origin}
              </span>
            </div>

            <h3 className="if-name">{INGREDIENT.nameDisplay}</h3>
            <p className="if-tagline">
              <span className="if-tagline-pull">«Tres estigmas por flor.»</span>
            </p>
            <p className="if-description">{INGREDIENT.description}</p>

            <div className="if-tags">
              <span className="if-tags-label">Perfil aromático</span>
              <div className="if-tag-row">
                {INGREDIENT.flavors.map((f, i) => (
                  <span key={f} className="if-tag" style={{ "--i": i }}>{f}</span>
                ))}
              </div>
            </div>

            <div className="if-tags">
              <span className="if-tags-label">Marida con</span>
              <p className="if-pairs">
                {INGREDIENT.pairs_with.join(" · ")}
              </p>
            </div>

            <a className="if-cta" href={`#/ingrediente/azafran`}>
              Ver {INGREDIENT.recipes_count} recetas con azafrán
              <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 10h12M11 5l5 5-5 5"/>
              </svg>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   Page composer
   ============================================================ */
function HomeSections() {
  return (
    <main className="hs-page">
      {/* Mini top bar to anchor the magazine spread */}
      <header className="hs-topbar">
        <div className="hs-tb-left">domingo, 17 de mayo de 2026 · Edición España &amp; LATAM</div>
        <a href="#/" className="hs-logo">worldwiderecipes<span>.app</span></a>
        <nav className="hs-nav">
          <a href="#/explorar">Explorar</a>
          <a href="#/colecciones">Colecciones</a>
          <a href="#/tiktok">TikTok</a>
          <a href="#/entrar">Entrar</a>
        </nav>
      </header>

      <div className="hs-hint">
        <span>Vista previa de tres secciones del homepage. Haz scroll lentamente para ver las animaciones.</span>
      </div>

      <CuisineGrid />
      <TechniqueOfDay />
      <IngredientFeature />

      <footer className="hs-footer">
        <span>© 2026 worldwiderecipes.app · Madrid · Ciudad de México</span>
        <span>Tres secciones · Una misma página</span>
      </footer>
    </main>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<HomeSections />);
